# Claude Code Tutorial for Quantitative Social Scientists

A 20-minute hands-on introduction to Claude Code for research workflows.

## Overview

**Duration**: ~20 minutes
**Audience**: Researchers familiar with R, Stata, or Python
**Approach**: Learn by doing - you'll work through a complete data workflow

## Prerequisites

### 1. Claude Subscription

You need one of:
- Claude Pro subscription ($20/month)
- Claude Max subscription
- Claude Teams or Enterprise access

### 2. Install Claude Code

**Windows users**: See **[INSTALL_WINDOWS.md](INSTALL_WINDOWS.md)** for a step-by-step guide covering common pitfalls.

**Mac/Linux users**: Open your terminal and run:
```bash
# Mac
brew install claude-code

# Linux / Mac (alternative)
curl -fsSL https://claude.ai/install.sh | sh
```

**Verify installation**:
```bash
claude --version
```

### 3. Statistical Software

Have one of the following installed:
- **R** (with tidyverse, fixest)
- **Python** (with pandas, statsmodels, matplotlib)
- **Stata** (v15+)

## Quick Start

1. **Download this tutorial folder** to your computer

2. **Open a terminal** and navigate to the folder:
   ```bash
   cd path/to/tutorial
   ```

3. **Start Claude Code**:
   ```bash
   claude
   ```

4. **Start the interactive tutorial**:
   ```
   /tutorial start
   ```

Or open `TUTORIAL.md` and work through it at your own pace.

## What You'll Do

| Module | Time | What Happens |
|--------|------|--------------|
| 0. Quick Start | ~3 min | Get oriented, learn about CLAUDE.md |
| 1. Working with Data | ~15 min | Diagnose, clean, explore, think about causality |

You'll work with a messy dataset about workers and wages, exploring the relationship between union membership and wages.

## Contents

```
tutorial/
├── README.md                 # This file
├── TUTORIAL.md              # Main tutorial (start here!)
├── sample_data/
│   ├── admin_data_messy.csv # Sample dataset for exercises
│   ├── codebook.txt         # Variable descriptions
│   └── README.md            # Data documentation
├── modules/                  # Optional deep-dive guides
│   ├── memory_module.md     # Managing context and long projects
│   ├── prompting_module.md  # Best practices for effective prompts
│   ├── skills_module.md     # Using and creating reusable skills
│   ├── data_acquisition_module.md  # Finding datasets and scraping web data
│   ├── literature_module.md # Literature review workflows
│   └── paper_workflow_module.md    # Publication-ready tables and figures
├── resources/
│   ├── cheatsheet.md        # Quick reference card
│   └── ...                  # Additional resources
├── output/                   # Generated files go here
│   ├── tables/
│   └── figures/
└── solutions/                # Reference implementations
```

## Troubleshooting

### "command not found: claude"
- Close and reopen your terminal
- Check installation: `which claude` or `where claude`
- Try reinstalling with the native installer

### Permission errors
- Claude Code asks before reading/editing files
- Type `y` to allow, `n` to deny, `a` to always allow

### Need help during tutorial
- Type `/help` for available commands
- Ask Claude: "What commands are available?"

## Optional Modules

After the main tutorial, explore these reference guides (~5 min each):

| Module | When to Read |
|--------|--------------|
| `modules/memory_module.md` | Before starting a multi-session project |
| `modules/prompting_module.md` | When you want to get better results from Claude |
| `modules/skills_module.md` | When you want to create reusable workflows |
| `modules/agents_module.md` | When you want focused, specialized review of your work |
| `modules/data_acquisition_module.md` | When finding or downloading data from the web |
| `modules/literature_module.md` | When doing literature review with Claude |
| `modules/paper_workflow_module.md` | When creating journal-ready tables and figures |

## Resources

- **Official Claude Code docs**: https://docs.anthropic.com/en/docs/claude-code
- **Best practices**: https://www.anthropic.com/engineering/claude-code-best-practices

## Feedback

This tutorial was developed for the MIT quantitative social science community. For feedback or issues, contact [your contact info].

---

*Version 2.0 - January 2026*
