# =============================================================================
# Solution Script: Data Cleaning
# Claude Code Tutorial - Module 1
# =============================================================================

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime

# =============================================================================
# Load Raw Data
# =============================================================================

base_dir = Path(__file__).resolve().parent.parent
raw_data = pd.read_csv(base_dir / "sample_data" / "admin_data_messy.csv", dtype=str)

print(f"Starting N: {len(raw_data)}")

# =============================================================================
# Step 1: Diagnose Data Quality Issues
# =============================================================================

# Check for duplicates
duplicate_ids = raw_data[raw_data.duplicated(subset=["id"], keep=False)].sort_values("id")
print(f"\nDuplicate ID records: {len(duplicate_ids)}")

# Check unique values for categorical variables
print("\nUnique gender values:")
print(raw_data["gender"].value_counts(dropna=False))

print("\nUnique industry values:")
print(raw_data["industry_code"].value_counts(dropna=False))

# Check for impossible age values
ages_numeric = pd.to_numeric(raw_data["age"], errors="coerce")
print(f"\nAge distribution:")
print(ages_numeric.describe())
print(f"Ages < 0 or > 100: {((ages_numeric < 0) | (ages_numeric > 100)).sum()}")

# =============================================================================
# Step 2: Standardize Missing Values
# =============================================================================

missing_codes = ["-99", "", "NA", "missing", "Missing", ".", "N/A", "nan"]

df = raw_data.copy()
df = df.replace(missing_codes, np.nan)

print("\nNA counts after standardization:")
print(df.isna().sum())

# =============================================================================
# Step 3: Convert Variable Types
# =============================================================================

df["id"] = pd.to_numeric(df["id"], errors="coerce").astype("Int64")
df["age"] = pd.to_numeric(df["age"], errors="coerce")

# Education: handle word-coded values
education_word_map = {
    "ten": 10, "twelve": 12, "fourteen": 14,
    "sixteen": 16, "eighteen": 18, "twenty": 20,
}
df["education_years"] = df["education_years"].map(education_word_map).fillna(
    pd.to_numeric(df["education_years"], errors="coerce")
)

df["experience"] = pd.to_numeric(df["experience"], errors="coerce")
df["hourly_wage"] = pd.to_numeric(df["hourly_wage"], errors="coerce")
df["union_member"] = pd.to_numeric(df["union_member"], errors="coerce")

# =============================================================================
# Step 4: Standardize Gender
# =============================================================================

female_codes = ["F", "f", "Female", "FEMALE", "female", "Woman", "0"]
male_codes = ["M", "m", "Male", "MALE", "male", "Man", "1"]

df["female"] = np.where(
    df["gender"].isin(female_codes), 1,
    np.where(df["gender"].isin(male_codes), 0, np.nan)
)

print("\nGender recoding:")
print(pd.crosstab(raw_data["gender"], df["female"], dropna=False))

# =============================================================================
# Step 5: Standardize Industry
# =============================================================================

industry_map = {
    "Manufacturing": ["Manufacturing", "manufacturing", "MANUFACTURING", "MANUF", "Manuf.", "1"],
    "Retail": ["Retail", "retail", "RETAIL", "Retail Trade", "2"],
    "Finance": ["Finance", "finance", "FINANCE", "Financial", "Fin.", "3"],
    "Healthcare": ["Healthcare", "healthcare", "HEALTHCARE", "Health Care", "Medical", "4"],
    "Education": ["Education", "education", "EDUCATION", "Edu", "5"],
    "Technology": ["Technology", "technology", "TECHNOLOGY", "Tech", "IT", "6"],
    "Utilities": ["Utilities", "utilities", "UTILITIES", "Util", "7"],
    "Construction": ["Construction", "construction", "CONSTRUCTION", "Constr.", "8"],
    "Transportation": ["Transportation", "transportation", "TRANSPORTATION", "Transport", "9"],
    "Services": ["Services", "services", "SERVICES", "Service", "Other Services", "10"],
}

# Invert the map: original_value -> standardized_name
inv_map = {}
for standard, variants in industry_map.items():
    for v in variants:
        inv_map[v] = standard

df["industry"] = df["industry_code"].map(inv_map)

print("\nIndustry standardization:")
print(df["industry"].value_counts(dropna=False))

# =============================================================================
# Step 6: Standardize Region
# =============================================================================

region_map_dict = {}
for std, variants in {1: ["1", "Northeast", "NE"], 2: ["2", "Midwest", "MW"],
                       3: ["3", "South", "S"], 4: ["4", "West", "W"]}.items():
    for v in variants:
        region_map_dict[v] = std

df["region"] = df["region"].map(region_map_dict)

# =============================================================================
# Step 7: Standardize Firm Size
# =============================================================================

firm_size_map_dict = {}
for std, variants in {
    "small": ["small", "Small", "SMALL", "<50", "1", "S"],
    "medium": ["medium", "Medium", "MEDIUM", "50-500", "2", "M"],
    "large": ["large", "Large", "LARGE", ">500", "3", "L"],
}.items():
    for v in variants:
        firm_size_map_dict[v] = std

df["firm_size"] = df["firm_size"].map(firm_size_map_dict)

# =============================================================================
# Step 8: Parse Dates
# =============================================================================

date_formats = ["%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%b %d, %Y", "%B %d, %Y", "%m-%d-%Y"]

def parse_date_multi(x):
    if pd.isna(x):
        return pd.NaT
    for fmt in date_formats:
        try:
            return datetime.strptime(str(x).strip(), fmt)
        except (ValueError, TypeError):
            continue
    return pd.NaT

df["survey_date_clean"] = df["survey_date"].apply(parse_date_multi)
df["year"] = df["survey_date_clean"].dt.year

# =============================================================================
# Step 9: Remove Duplicates
# =============================================================================

n_before_dedup = len(df)
df = df.sort_values(["id", "survey_date_clean"]).drop_duplicates(subset=["id"], keep="first")
print(f"\nRecords removed as duplicates: {n_before_dedup - len(df)}")

# =============================================================================
# Step 10: Handle Outliers
# =============================================================================

# Age: Remove impossible values
n_before_age = len(df)
df = df[df["age"].isna() | ((df["age"] >= 18) & (df["age"] <= 70))]
print(f"Records removed for impossible age: {n_before_age - len(df)}")

# Wage: Flag outliers but don't remove yet
df["wage_outlier"] = (df["hourly_wage"] < 0) | (df["hourly_wage"] > 200)
df["log_wage"] = np.where(df["hourly_wage"] > 0, np.log(df["hourly_wage"]), np.nan)

print(f"Wage outliers flagged: {df['wage_outlier'].sum()}")

# =============================================================================
# Step 11: Select and Rename Final Variables
# =============================================================================

df_clean = df[["id", "age", "female", "education_years", "experience",
               "hourly_wage", "log_wage", "wage_outlier", "industry",
               "region", "year", "union_member", "firm_size"]].copy()

# =============================================================================
# Step 12: Save Cleaned Data
# =============================================================================

output_path = base_dir / "sample_data" / "survey_clean.csv"
df_clean.to_csv(output_path, index=False)

print(f"\n=== CLEANING SUMMARY ===")
print(f"Starting N: {len(raw_data)}")
print(f"Final N: {len(df_clean)}")
print(f"Records removed for impossible age: {n_before_age - len(df)}")
print(f"Wage outliers flagged (not removed): {df_clean['wage_outlier'].sum()}")
print(f"\nCleaned data saved to: {output_path}")

# =============================================================================
# Create Cleaning Log
# =============================================================================

cleaning_log = f"""# Data Cleaning Log

## Source
- File: sample_data/admin_data_messy.csv
- Date cleaned: {datetime.today().strftime('%Y-%m-%d')}

## Sample Size
- Starting N: {len(raw_data)}
- Final N: {len(df_clean)}

## Actions Taken

### Missing Values
- Standardized multiple missing codes (-99, '', 'NA', 'missing', '.', etc.) to NaN
- Affected columns: experience, union_member, hourly_wage, education_years

### Duplicates
- Identified {len(duplicate_ids)} duplicate ID records
- Kept first occurrence, removed duplicates

### Age
- Removed {n_before_age - len(df)} records with impossible ages (<18 or >70)

### Gender
- Standardized 8 different codings to binary female indicator (0/1)

### Industry
- Standardized inconsistent industry codes to 10 categories

### Region
- Standardized numeric and string region codes to 1-4

### Firm Size
- Standardized to: small, medium, large

### Dates
- Parsed multiple date formats to standard datetime
- Extracted year for analysis

### Wages
- Flagged {int(df_clean['wage_outlier'].sum())} outliers (negative or >$200/hr)
- Created log_wage for analysis
- Did NOT remove outliers (pending decision)

## Variables in Clean Data
id, age, female, education_years, experience, hourly_wage, log_wage,
wage_outlier, industry, region, year, union_member, firm_size
"""

log_path = base_dir / "output" / "cleaning_log.md"
log_path.parent.mkdir(parents=True, exist_ok=True)
log_path.write_text(cleaning_log)
print(f"\nCleaning log saved to: {log_path}")
