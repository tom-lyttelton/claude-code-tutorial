# Finding and Getting Online Data
*Reference Guide (~5 min read)*

---

Research often requires finding new datasets or pulling data from the web. Claude can help you locate data sources, download files, and work with APIs - but knowing the limitations matters.

## Using Claude to Find Datasets

Claude can suggest relevant datasets based on your research question:

```
What public datasets exist for studying wage inequality in the US?
```

```
I need panel data on firm-level employment. What sources should I consider?
```

**What Claude can do**:
- Suggest well-known datasets (IPUMS, BLS, Census, etc.)
- Describe what variables are typically available
- Point you to documentation and access procedures
- Compare trade-offs between different sources

**What Claude cannot do**:
- Access datasets that require login or institutional authentication
- Scrape JavaScript-heavy data portals without browser tools (e.g., Playwright)

Claude **can** search the web in real time using built-in tools (`WebSearch`, `WebFetch`), so it can find recent data releases and check current availability. But always verify terms of use and access procedures at the source.

## Downloading Data

### Direct Downloads

For publicly accessible files:

```
Download the CSV file from https://example.gov/data/employment.csv
and save it to data/raw/
```

Claude will use `curl` or `wget` to fetch the file.

### From Data Portals

Many data portals (ICPSR, Dataverse, government sites) require:
- Creating an account
- Agreeing to terms of use
- Manual download through their interface

Claude cannot bypass these requirements. Download manually, then:

```
I downloaded employment_data.zip to my Downloads folder.
Move it to data/raw/ and extract it.
```

### API Access

For APIs with authentication (Census, BLS, FRED):

```
I have a Census API key: [your-key]
Pull county-level population data for 2020 from the ACS.
```

Claude will write the API request code and execute it. Keep your API keys in a `.env` file, not in your code.

## Web Scraping Basics

### When Scraping Is Appropriate

- The data is publicly accessible
- No API is available
- The site's robots.txt and terms allow scraping
- You're not overloading the server

### Simple Scraping Patterns

For a single page:
```
Scrape the faculty list from https://sociology.university.edu/people
and extract names, titles, and email addresses.
```

For multiple pages:
```
Scrape all faculty profiles from the economics department pages.
Wait 2 seconds between requests to be polite to the server.
```

### Rate Limiting and Ethics

Always be a good citizen:
- Add delays between requests (1-2 seconds minimum)
- Don't scrape during peak hours
- Cache results to avoid re-scraping
- Respect robots.txt

```
Scrape this site with a 2-second delay between pages.
Save progress so we can resume if interrupted.
```

## Working with APIs

### Reading API Documentation

Ask Claude to help interpret API docs:

```
Here's the BLS API documentation: [paste or link]
How do I request unemployment rates for California, 2015-2023?
```

### Making Authenticated Requests

Most research APIs require keys. Set up once:

```
Create a .env file with my API keys:
CENSUS_API_KEY=your_key_here
FRED_API_KEY=your_key_here
```

Then use them:
```
Using my Census API key from .env, pull median household income
by county for 2019.
```

### Parsing JSON Responses

API responses are typically JSON. Claude handles the parsing:

```
Query the FRED API for the unemployment rate series,
parse the response, and save as a clean CSV.
```

## Common Pitfalls

1. **Assuming Claude can access everything** - Many sites block automated access, require login, or serve JavaScript-rendered content that simple requests can't capture.

2. **Forgetting rate limits** - APIs and websites have rate limits. Exceeding them gets you blocked. Always add delays.

3. **Not checking data terms** - Some datasets prohibit redistribution or have specific citation requirements. Read the terms before using.

4. **Stale URLs** - Government data URLs change frequently. If a download fails, search for the current location manually.

5. **Missing authentication** - If an API call fails, the first thing to check is whether you're authenticated correctly.

## Quick Reference

| Task | Approach |
|------|----------|
| Find datasets | "What datasets exist for [topic]?" |
| Download public file | "Download [URL] to data/raw/" |
| Scrape webpage | "Scrape [URL] and extract [fields]" |
| Use API with key | Store key in .env, reference in request |
| Rate limiting | "Add 2-second delay between requests" |
| Parse API response | "Query [API], parse JSON, save as CSV" |
| Handle authentication | Manual login/download, then let Claude process |

---

*Part of the Claude Code Tutorial for Quantitative Social Scientists*
