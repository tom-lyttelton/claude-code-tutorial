# Prompting Best Practices
*Reference Guide (~5 min read)*

---

How you ask Claude to do something affects what you get back. Good prompts lead to useful results on the first try. Poor prompts lead to back-and-forth clarification or outputs that miss the mark.

## The Core Principle

**Be specific about what you want, but not about how to do it.**

Claude is good at figuring out implementation details. Your job is to clearly describe the goal and any constraints.

## Structure of a Good Prompt

A complete prompt often includes:

1. **Context**: What are you working on?
2. **Task**: What do you want Claude to do?
3. **Constraints**: What requirements or limitations apply?
4. **Output format**: How should the result be presented?

Not every prompt needs all four elements, but being explicit helps.

### Example: Weak vs. Strong Prompts

**Weak**:
```
Clean this data
```

**Strong**:
```
Clean admin_data.csv for analysis. Handle these issues:
- Multiple missing value codes (-99, "", "NA", "missing")
- Inconsistent gender coding (M/F/Male/Female/0/1)
- Age outliers (negative or >100)

Save cleaned data to output/admin_data_clean.csv.
Report how many rows were dropped and why.
```

The strong prompt tells Claude what problems exist, what to do about them, and what output you need.

## Key Prompting Patterns

### 1. Diagnose Before Fixing

Don't jump straight to solutions:
```
Diagnose all data quality issues in survey.csv.
Don't fix anything yet - just report what you find.
```

Then review the diagnosis before asking for fixes. This catches issues you might not have anticipated.

### 2. Explain Then Execute

Ask Claude to explain its plan before running code:
```
Before running anything, explain how you'll approach
this regression analysis and what specifications you'll use.
```

This gives you a chance to course-correct before Claude does a lot of work.

### 3. Constrain the Scope

Prevent over-engineering by being explicit about limits:
```
Add a simple bar chart of wage by education level.
Don't add interactivity, themes, or extra formatting -
just a basic ggplot with clear labels.
```

### 4. Request Specific Output Formats

Be clear about what you want back:
```
Create a summary table with these columns:
- Variable name
- N (non-missing)
- Mean
- SD
- Min
- Max

Export as both CSV and formatted markdown.
```

### 5. Provide Examples

When the format matters, show what you want:
```
Rename variables to follow this pattern:
- wage_hourly (not hourlyWage or Hourly.Wage)
- years_education (not yrs_ed or educYears)
- is_union_member (not union or UnionMember)
```

## Prompts for Common Tasks

### Data Cleaning
```
Clean [file] for analysis:
- Standardize missing values to NA
- Fix inconsistent categorical coding
- Flag (don't drop) outliers in [variable]
- Save cleaned data to [path]
- Report all changes made with counts
```

### Exploration
```
Explore the relationship between [X] and [Y]:
- Summary statistics by group
- Visualization of the distribution
- Correlation or cross-tabulation as appropriate
- Note any obvious confounders in the data
```

### Regression Analysis
```
Regress [Y] on [X] with these specifications:
1. Bivariate
2. Adding controls: [list]
3. Adding fixed effects: [list]

Cluster standard errors at [level].
Present results in a single table.
```

### Creating Figures
```
Create a [plot type] showing [relationship].
- Use clean axis labels (no variable names)
- Add a title that describes the finding
- Size for a journal column (6 inches wide)
- Save as PDF to output/figures/
```

## What to Do When Results Are Wrong

### Be More Specific
If Claude misunderstands, add detail:
```
That's not quite right. The union variable should be
treated as binary (0/1), not continuous. Re-run the
regression treating it as a factor.
```

### Show the Error
When something breaks, share the full error:
```
That gave an error. Here's the message:
[paste error]

What's causing this and how do we fix it?
```

### Ask for Alternatives
If one approach isn't working:
```
That method isn't working for this data structure.
What are two other approaches we could try?
```

## Prompts to Avoid

### Too Vague
```
Analyze this data
```
What kind of analysis? What questions are you trying to answer?

### Too Prescriptive
```
Write a function called clean_data that takes a dataframe,
loops through columns, checks if typeof is character,
then uses gsub to replace...
```
Tell Claude what you need, not how to code it.

### Multiple Unrelated Tasks
```
Clean the data, run regressions, make figures, and
write up the methods section
```
Break complex work into sequential steps.

## Common Pitfalls

1. **Not reading Claude's output** - Claude often asks clarifying questions or notes assumptions. Read the full response.

2. **Asking for too much at once** - Complex tasks should be broken into steps. Let Claude complete one before starting the next.

3. **Forgetting context** - Each prompt should contain enough information to stand alone. Don't assume Claude remembers details from earlier.

4. **Not specifying output location** - Always say where files should be saved, or Claude will choose for you.

5. **Skipping verification** - After Claude produces output, check it. Ask Claude to verify its own work when appropriate.

## Quick Reference

| Goal | Prompt Pattern |
|------|----------------|
| Understand before acting | "Diagnose X. Don't fix yet." |
| Prevent surprises | "Explain your approach before running code." |
| Keep it simple | "Add a simple X. Don't add extra features." |
| Get usable output | "Export as [format] to [path]." |
| Show what you want | "Follow this pattern: [example]" |
| Fix mistakes | "That's not right because [reason]. Instead, [correction]." |
| Debug errors | "This error occurred: [message]. What's wrong?" |

---

*Part of the Claude Code Tutorial for Quantitative Social Scientists*
