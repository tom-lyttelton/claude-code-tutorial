# =============================================================================
# Solution Script: Data Exploration
# Claude Code Tutorial - Module 2
# =============================================================================

# Load required packages
library(tidyverse)
library(here)
library(scales)
library(knitr)

# =============================================================================
# Load Cleaned Data
# =============================================================================

df <- read_csv(here("sample_data", "survey_clean.csv"))

cat("Loaded", nrow(df), "observations\n")

# =============================================================================
# Summary Statistics
# =============================================================================

# Function to compute summary stats
summary_stats <- function(x) {
  tibble(
    N = sum(!is.na(x)),
    Mean = mean(x, na.rm = TRUE),
    SD = sd(x, na.rm = TRUE),
    Min = min(x, na.rm = TRUE),
    Max = max(x, na.rm = TRUE),
    Pct_Missing = mean(is.na(x)) * 100
  )
}

# Continuous variables
continuous_vars <- c("age", "education_years", "experience", "hourly_wage", "log_wage")

stats_continuous <- map_dfr(continuous_vars, function(var) {
  summary_stats(df[[var]]) %>%
    mutate(Variable = var, .before = 1)
})

# Round for display
stats_continuous <- stats_continuous %>%
  mutate(across(where(is.numeric), ~round(., 2)))

cat("\n=== Summary Statistics: Continuous Variables ===\n")
print(stats_continuous)

# Save to CSV
write_csv(stats_continuous, here("output", "tables", "summary_stats_continuous.csv"))

# Categorical variables
cat("\n=== Summary Statistics: Categorical Variables ===\n")

cat("\nFemale:\n")
print(table(df$female, useNA = "ifany"))
cat("Proportion female:", mean(df$female, na.rm = TRUE), "\n")

cat("\nUnion Member:\n")
print(table(df$union_member, useNA = "ifany"))
cat("Proportion union:", mean(df$union_member, na.rm = TRUE), "\n")

cat("\nIndustry:\n")
print(table(df$industry, useNA = "ifany"))

cat("\nRegion:\n")
print(table(df$region, useNA = "ifany"))

cat("\nFirm Size:\n")
print(table(df$firm_size, useNA = "ifany"))

cat("\nYear:\n")
print(table(df$year, useNA = "ifany"))

# =============================================================================
# Visualizations
# =============================================================================

# 1. Wage Distribution
p1 <- ggplot(df %>% filter(!wage_outlier), aes(x = hourly_wage)) +
  geom_histogram(bins = 30, fill = "steelblue", color = "white", alpha = 0.7) +
  labs(
    title = "Distribution of Hourly Wages",
    subtitle = "Outliers excluded (wage < 0 or > $200)",
    x = "Hourly Wage ($)",
    y = "Count"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(face = "bold"))

ggsave(here("output", "figures", "wage_distribution.png"), p1, width = 8, height = 5)

# 2. Log Wage Distribution
p2 <- ggplot(df %>% filter(!is.na(log_wage) & !wage_outlier), aes(x = log_wage)) +
  geom_histogram(bins = 30, fill = "darkgreen", color = "white", alpha = 0.7) +
  labs(
    title = "Distribution of Log Hourly Wages",
    subtitle = "Outliers excluded",
    x = "Log(Hourly Wage)",
    y = "Count"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(face = "bold"))

ggsave(here("output", "figures", "log_wage_distribution.png"), p2, width = 8, height = 5)

# 3. Wage by Union Status
p3 <- df %>%
  filter(!wage_outlier & !is.na(union_member)) %>%
  mutate(Union = ifelse(union_member == 1, "Union", "Non-Union")) %>%
  ggplot(aes(x = Union, y = hourly_wage, fill = Union)) +
  geom_boxplot(alpha = 0.7) +
  scale_fill_manual(values = c("Non-Union" = "gray60", "Union" = "steelblue")) +
  labs(
    title = "Hourly Wage by Union Status",
    x = "",
    y = "Hourly Wage ($)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold"),
    legend.position = "none"
  )

ggsave(here("output", "figures", "wage_by_union.png"), p3, width = 6, height = 5)

# 4. Wage by Union - Density
p4 <- df %>%
  filter(!wage_outlier & !is.na(union_member)) %>%
  mutate(Union = ifelse(union_member == 1, "Union", "Non-Union")) %>%
  ggplot(aes(x = hourly_wage, fill = Union)) +
  geom_density(alpha = 0.5) +
  scale_fill_manual(values = c("Non-Union" = "gray60", "Union" = "steelblue")) +
  labs(
    title = "Wage Distribution by Union Status",
    x = "Hourly Wage ($)",
    y = "Density"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(face = "bold"))

ggsave(here("output", "figures", "wage_density_by_union.png"), p4, width = 8, height = 5)

cat("\nFigures saved to output/figures/\n")

# =============================================================================
# Correlation Matrix
# =============================================================================

# Select numeric variables for correlation
cor_vars <- df %>%
  filter(!wage_outlier) %>%
  select(age, education_years, experience, hourly_wage, female, union_member) %>%
  drop_na()

cor_matrix <- cor(cor_vars)

cat("\n=== Correlation Matrix ===\n")
print(round(cor_matrix, 3))

# Save correlation matrix
write_csv(as_tibble(cor_matrix, rownames = "Variable"),
          here("output", "tables", "correlation_matrix.csv"))

# =============================================================================
# Key Bivariate Relationships
# =============================================================================

cat("\n=== Wage by Union Status ===\n")
wage_by_union <- df %>%
  filter(!wage_outlier & !is.na(union_member)) %>%
  group_by(union_member) %>%
  summarize(
    N = n(),
    Mean_Wage = mean(hourly_wage, na.rm = TRUE),
    SD_Wage = sd(hourly_wage, na.rm = TRUE),
    Median_Wage = median(hourly_wage, na.rm = TRUE)
  ) %>%
  mutate(Union_Status = ifelse(union_member == 1, "Union", "Non-Union"))

print(wage_by_union)
write_csv(wage_by_union, here("output", "tables", "wage_by_union.csv"))

cat("\nRaw union wage premium:",
    wage_by_union$Mean_Wage[wage_by_union$union_member == 1] -
    wage_by_union$Mean_Wage[wage_by_union$union_member == 0], "\n")

cat("\n=== Wage by Union Status and Industry ===\n")
wage_by_union_industry <- df %>%
  filter(!wage_outlier & !is.na(union_member) & !is.na(industry)) %>%
  group_by(industry, union_member) %>%
  summarize(
    N = n(),
    Mean_Wage = mean(hourly_wage, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_wider(names_from = union_member, values_from = c(N, Mean_Wage),
              names_glue = "{.value}_{union_member}")

print(wage_by_union_industry)
write_csv(wage_by_union_industry, here("output", "tables", "wage_by_union_industry.csv"))

cat("\n=== Wage by Union Status and Region ===\n")
wage_by_union_region <- df %>%
  filter(!wage_outlier & !is.na(union_member) & !is.na(region)) %>%
  group_by(region, union_member) %>%
  summarize(
    N = n(),
    Mean_Wage = mean(hourly_wage, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_wider(names_from = union_member, values_from = c(N, Mean_Wage),
              names_glue = "{.value}_{union_member}")

print(wage_by_union_region)
write_csv(wage_by_union_region, here("output", "tables", "wage_by_union_region.csv"))

# =============================================================================
# Generate Exploration Report
# =============================================================================

report <- sprintf('
# Data Exploration Report

## 1. Data Overview

**Source**: Administrative worker survey data (simulated)
**Time Period**: 2020-2024
**Unit of Analysis**: Individual worker
**Sample Size**: %d observations (after cleaning)

### Sample Construction
- Started with 812 raw records
- Removed duplicates and records with impossible ages
- Flagged %d wage outliers (not removed from analysis sample)

## 2. Variable Descriptions

### Outcome Variable
- **hourly_wage**: Hourly wage in US dollars
  - Mean: $%.2f, SD: $%.2f
  - Range: $%.2f - $%.2f
  - Right-skewed distribution; log transformation recommended

### Key Independent Variable
- **union_member**: Binary indicator (1 = union member)
  - Union membership rate: %.1f%%
  - N union members: %d
  - N non-union: %d

### Control Variables
- **age**: Age in years (Mean: %.1f, SD: %.1f)
- **female**: Binary indicator (%.1f%% female)
- **education_years**: Years of education (Mean: %.1f)
- **experience**: Years of work experience (Mean: %.1f)

### Fixed Effects Variables
- **industry**: 10 categories (Manufacturing largest at %.1f%%)
- **region**: 4 regions (approximately equal distribution)
- **year**: 2020-2024

## 3. Key Distributions

### Wage Distribution
- Hourly wages range from $%.2f to $%.2f (excluding outliers)
- Distribution is right-skewed
- **Recommendation**: Use log(wage) as outcome variable

See figures:
- `output/figures/wage_distribution.png`
- `output/figures/log_wage_distribution.png`

### Union Membership
- Overall rate: %.1f%%
- Varies by industry (highest in Utilities, lowest in Retail)

## 4. Bivariate Relationships

### Union-Wage Relationship (Key Finding)
| Status | N | Mean Wage | SD |
|--------|---|-----------|-----|
| Non-Union | %d | $%.2f | $%.2f |
| Union | %d | $%.2f | $%.2f |

**Raw union premium**: $%.2f (%.1f%%)

See figure: `output/figures/wage_by_union.png`

### Patterns by Industry
- Strong industry differences in wages
- Finance and Technology highest paid
- Retail and Services lowest paid
- Union premium varies by industry

### Patterns by Region
- Regional wage differences present
- Union premium relatively consistent across regions

## 5. Correlation Matrix

Key correlations:
- Age and experience: r = %.3f (high, as expected - do not include both)
- Education and wage: r = %.3f (positive)
- Union and wage: r = %.3f (positive)

## 6. Implications for Analysis

### Functional Form
- Use **log(hourly_wage)** as outcome (right-skewed distribution)
- Coefficients will represent approximate percent changes

### Identification
- Cannot make strong causal claims (selection into union membership)
- Control for observable characteristics
- Use industry and year fixed effects

### Controls to Include
- **age** (or experience, but not both - highly correlated)
- **education_years**
- **female**
- **firm_size** (may be mediator - test with and without)

### Fixed Effects
- **industry**: Strong wage differences across industries
- **year**: Control for time trends

### Robustness Checks to Consider
1. Alternative FE structures (region FE, industry × year FE)
2. Drop wage outliers entirely
3. Different sample restrictions (e.g., age 25-55)
4. Include/exclude potential mediators (firm size)

### Limitations to Acknowledge
- Selection bias: workers who join unions may differ systematically
- No panel structure: cannot control for unobserved individual heterogeneity
- Self-reported data may contain measurement error

---

*Report generated: %s*
',
nrow(df),
sum(df$wage_outlier, na.rm = TRUE),
mean(df$hourly_wage[!df$wage_outlier], na.rm = TRUE),
sd(df$hourly_wage[!df$wage_outlier], na.rm = TRUE),
min(df$hourly_wage[!df$wage_outlier], na.rm = TRUE),
max(df$hourly_wage[!df$wage_outlier], na.rm = TRUE),
mean(df$union_member, na.rm = TRUE) * 100,
sum(df$union_member == 1, na.rm = TRUE),
sum(df$union_member == 0, na.rm = TRUE),
mean(df$age, na.rm = TRUE),
sd(df$age, na.rm = TRUE),
mean(df$female, na.rm = TRUE) * 100,
mean(df$education_years, na.rm = TRUE),
mean(df$experience, na.rm = TRUE),
max(table(df$industry)) / nrow(df) * 100,
min(df$hourly_wage[!df$wage_outlier], na.rm = TRUE),
max(df$hourly_wage[!df$wage_outlier], na.rm = TRUE),
mean(df$union_member, na.rm = TRUE) * 100,
wage_by_union$N[wage_by_union$union_member == 0],
wage_by_union$Mean_Wage[wage_by_union$union_member == 0],
wage_by_union$SD_Wage[wage_by_union$union_member == 0],
wage_by_union$N[wage_by_union$union_member == 1],
wage_by_union$Mean_Wage[wage_by_union$union_member == 1],
wage_by_union$SD_Wage[wage_by_union$union_member == 1],
wage_by_union$Mean_Wage[wage_by_union$union_member == 1] - wage_by_union$Mean_Wage[wage_by_union$union_member == 0],
(wage_by_union$Mean_Wage[wage_by_union$union_member == 1] / wage_by_union$Mean_Wage[wage_by_union$union_member == 0] - 1) * 100,
cor_matrix["age", "experience"],
cor_matrix["education_years", "hourly_wage"],
cor_matrix["union_member", "hourly_wage"],
Sys.Date()
)

writeLines(report, here("output", "data_exploration_report.md"))
cat("\n=== Exploration report saved to: output/data_exploration_report.md ===\n")
