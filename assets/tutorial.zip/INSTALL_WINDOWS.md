# Installing Claude Code on Windows

This guide walks you through installing Claude Code on a Windows machine. It covers the most common pitfalls and the simplest path to a working setup.

**Time required**: ~10 minutes

---

## What You Need Before Starting

1. **A Claude subscription** — Pro ($20/month), Max, Teams, or Enterprise. The free Claude.ai plan does not include Claude Code.

2. **Git for Windows** — Claude Code uses Git Bash internally to run commands. This is **mandatory**.
   - Download: https://git-scm.com/downloads/win
   - During installation, select **"Add to PATH"** when prompted
   - Accept the other defaults

3. **Windows 10 (version 1809+) or Windows 11**

If you already have Git installed, you can check by opening PowerShell and running:
```powershell
git --version
```
If it prints a version number, you're good.

---

## Installation: Pick One Method

### Option A: Native Installer (Recommended)

Open **PowerShell** (not CMD) and run:

```powershell
irm https://claude.ai/install.ps1 | iex
```

This downloads and installs Claude Code with automatic updates. No other dependencies needed.

> **If you see "irm is not recognized"**: You're in CMD, not PowerShell. Search for "PowerShell" in the Start menu and open it.

### Option B: WinGet

If you're on Windows 11 (or Windows 10 22H2+):

```powershell
winget install Anthropic.ClaudeCode
```

### Option C: Desktop App

Download the graphical installer from Anthropic's website. This gives you a desktop app with no terminal setup required:

https://claude.ai/download

---

## After Installation: Verify It Works

Close and reopen your terminal, then run:

```powershell
claude --version
```

You should see a version number. If instead you get **"claude is not recognized"**, see [Troubleshooting](#troubleshooting) below.

---

## First Run: Authentication

1. Run `claude` in your terminal
2. A browser window opens automatically for login
3. Sign in with your Claude account
4. Return to the terminal — you should see the Claude Code prompt

> If the browser doesn't open automatically, press `c` to copy the login URL to your clipboard, then paste it into your browser.

---

## Setting Up Your Statistical Software

Claude Code needs to be able to find your statistical software (R, Python, or Stata) from the command line.

**Test it first** — in the same terminal where Claude works, try:

| Software | Test Command | Expected Output |
|----------|-------------|-----------------|
| R | `Rscript --version` | Version number |
| Python | `python --version` | Version number |
| Stata | `"C:\Program Files\Stata18\StataMP-64.exe" /e version` | Version info |

If R or Python isn't found, it's usually a PATH issue — the terminal doesn't know where the program lives. You can fix this inside the tutorial by telling Claude your software's location (it will update CLAUDE.md for you), or see the [PATH fix](#r-or-python-not-found-in-terminal) below.

---

## Troubleshooting

### "claude" is not recognized

Claude Code installed but your terminal can't find it. Fix:

**Check if it's installed somewhere your PATH doesn't include:**
```powershell
$env:PATH -split ';' | Select-String 'local\\bin'
```

**If nothing shows up, add it:**
```powershell
$currentPath = [Environment]::GetEnvironmentVariable('PATH', 'User')
[Environment]::SetEnvironmentVariable('PATH', "$currentPath;$env:USERPROFILE\.local\bin", 'User')
```

Then **close and reopen your terminal** and try `claude --version` again.

### "Claude Code on Windows requires git-bash"

Git for Windows isn't installed or isn't in your PATH.

**Fix A**: Install Git for Windows from https://git-scm.com/downloads/win (make sure "Add to PATH" is checked).

**Fix B**: If Git is installed but Claude can't find it, tell Claude where it is. Create or edit the file `%USERPROFILE%\.claude\settings.json`:
```json
{
  "env": {
    "CLAUDE_CODE_GIT_BASH_PATH": "C:\\Program Files\\Git\\bin\\bash.exe"
  }
}
```

To find your actual Git path, run `where.exe git` in PowerShell, then use the `bin\bash.exe` in that same directory.

### R or Python not found in terminal

Your software is installed but the terminal doesn't know where it is.

**For R**: Open R (the GUI) and run `R.home("bin")`. This prints something like `C:/PROGRA~1/R/R-4.4.0/bin`. Add that to your system PATH, or note it down — you can tell Claude this path during the tutorial.

**For Python**: Run `where python` in PowerShell. If nothing comes up, you may need to:
1. Open the Python installer again and check "Add Python to PATH"
2. Or install Python from https://www.python.org/downloads/ with the PATH checkbox selected

### PowerShell script execution is blocked

If you get an error about "execution of scripts is disabled" when running the installer:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

Then retry the installation command.

### Behind a corporate proxy or firewall

Set your proxy before installing:
```powershell
$env:HTTPS_PROXY = "http://your-proxy:port"
irm https://claude.ai/install.ps1 | iex
```

### Diagnostics

If something else is wrong, Claude Code has a built-in diagnostic tool:
```powershell
claude doctor
```

This checks your system configuration and reports issues.

---

## Quick Summary

| Step | Command / Action |
|------|-----------------|
| 1. Install Git | https://git-scm.com/downloads/win |
| 2. Install Claude Code | `irm https://claude.ai/install.ps1 \| iex` (in PowerShell) |
| 3. Restart terminal | Close and reopen PowerShell |
| 4. Verify | `claude --version` |
| 5. Authenticate | Run `claude`, sign in via browser |
| 6. Start tutorial | `cd path\to\tutorial` then `claude` |

---

## Updating Claude Code

The native installer auto-updates in the background. You can also update manually:
```powershell
claude update
```

---

*If you hit an issue not covered here, run `/feedback` inside Claude Code to report it, or check https://github.com/anthropics/claude-code/issues*
