# Claude Code Quick Reference for Social Scientists

## Starting Claude Code

```bash
# Start in your project directory
cd /path/to/your/project
claude

# Start with a specific question
claude "How do I run a fixed effects regression in R?"

# Resume last conversation
claude -c
```

---

## Essential Slash Commands

| Command | What it does |
|---------|--------------|
| `/help` | Show all available commands |
| `/clear` | Reset context (use between unrelated tasks) |
| `/init` | Create a CLAUDE.md configuration file |
| `/compact` | Reduce context size when running low |

---

## Effective Prompting Patterns

### For Methods Questions
```
Explain [method] to someone familiar with [baseline knowledge].
What are the key assumptions of [method]?
When should I use [method A] vs [method B]?
What are common pitfalls when implementing [method]?
```

### For Data Discovery
```
What datasets are available for studying [topic]?
I need data on [variables] for [population/time period]. What are my options?
What are the limitations of [dataset] for studying [question]?
```

### For Analysis Planning
```
I want to estimate the effect of [X] on [Y]. What identification strategies could work?
Give me a plan for analyzing [question] - don't write code yet.
What robustness checks should I include for a [type of analysis]?
```

### For Code Generation
```
Write [R/Stata/Python] code to [task]. Use [specific packages] if needed.
Load [dataset] and run a regression of [Y] on [X] with [controls] and [fixed effects].
This code gives me [error]. What's wrong and how do I fix it?
```

### For Data Cleaning
```
I have data with [problems]. Generate code to clean it.
Merge [dataset A] with [dataset B] on [key], handling [specific issue].
Create a [derived variable] from [existing variables].
```

---

## The "Plan Before Code" Workflow

1. **Describe your goal**: "I want to analyze..."
2. **Ask for a plan**: "Give me a plan for this - don't write code yet"
3. **Review the plan**: Make sure it matches your intent
4. **Request implementation**: "Now implement step 1..."
5. **Verify each step**: Run code, check outputs

For complex problems, add "think hard" to your prompt:
```
Think hard about how to handle selection bias in this analysis.
```

---

## Understanding Permissions

When Claude asks for permission to:

| Action | What it means | Usually safe? |
|--------|---------------|---------------|
| Read file | Look at file contents | Yes |
| Edit file | Modify existing file | Review changes first |
| Write file | Create new file | Yes |
| Run bash command | Execute terminal command | Read carefully |

**Tip**: You can type `y` to allow, `n` to deny, or `a` to always allow that action.

---

## Critical Best Practices

### DO:
- **Understand every line** of generated code before running
- **Test incrementally** - run small pieces, check outputs
- **Ask Claude to explain** anything you don't understand
- **Verify results** against expectations or known quantities
- **Use `/clear`** between unrelated tasks
- **Create a CLAUDE.md** for recurring project settings

### DON'T:
- Accept code without understanding it ("vibe coding")
- Assume suggested packages/functions exist (test first)
- Trust statistical interpretations without verification
- Let AI make methodological decisions for you
- Share sensitive data in prompts

---

## CLAUDE.md Essentials

Create a `CLAUDE.md` in your project root:

```markdown
# Project: [Name]

## Software
- Primary language: [R / Python / Stata]
- Data stored in: data/
- Scripts in: code/

## Conventions
- Use snake_case for variables
- Comment non-obvious code
- Include standard errors in all regression output

## Common Tasks
- Data lives in data/raw/ (never modify)
- Cleaned data goes in data/cleaned/
```

---

## Quick Code Translation

Ask Claude to translate between languages:
```
Convert this Stata code to R:
[paste Stata code]

Rewrite this R code in Python using pandas:
[paste R code]
```

---

## Getting Help

- Type `/help` for command list
- Ask "How do I [task] in Claude Code?"
- Official docs: code.claude.com/docs
- Best practices: anthropic.com/engineering/claude-code-best-practices

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Ctrl+C` | Cancel current operation |
| `Escape` | Interrupt Claude (preserves context) |
| `Escape` x2 | Edit your last message |
| `Tab` | Autocomplete file paths |
| `Up arrow` | Scroll through previous prompts |

---

*Quick reference v1.0 - January 2026*
