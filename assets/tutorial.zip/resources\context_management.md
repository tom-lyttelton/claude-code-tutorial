# Managing Claude's Context Window in Long Research Projects

## The Problem

Claude Code has a context window of approximately 200,000 tokens. While this sounds large, it fills quickly during active research work:

| Content Type | Approximate Tokens |
|--------------|-------------------|
| 500-line R script | 2,000-3,000 |
| Data preview (100 rows × 10 cols) | 3,000-5,000 |
| Regression output | 500-1,000 |
| Each conversation turn | 200-1,000 |
| CLAUDE.md file | 500-2,000 |

In a typical 2-hour data analysis session, you might:
- Read 5-10 code files
- Preview data multiple times
- Run dozens of commands
- Have 50+ conversation turns

This can easily consume 50,000+ tokens, and the context accumulates across the session.

## Warning Signs You're Hitting Limits

1. **Claude "forgets" earlier context**
   - Asks about things you already discussed
   - Contradicts earlier statements
   - Doesn't remember file locations

2. **Responses become generic**
   - Less project-specific
   - More boilerplate suggestions
   - Loses your coding style

3. **System messages appear**
   - `/compact` suggestions
   - Context warnings

4. **Quality degradation**
   - More errors in generated code
   - Misses obvious context

---

## Strategy 1: CLAUDE.md as External Memory

### Why It Works
CLAUDE.md is read at the start of every session and periodically during long sessions. It's your persistent storage outside the context window.

### What to Include

**Essential sections:**
```markdown
# Project Name

## Quick Reference
- Main outcome variable and how it's measured
- Key treatment/independent variable
- Identification strategy in one sentence
- Sample definition

## Current Status
- Checklist of completed/pending tasks
- Current focus area

## Key Files
- Paths to important scripts and data
- Brief description of each

## Decisions Log
- Date-stamped record of analytical choices
- Why each decision was made

## Known Issues
- Data quirks
- Things to remember
- Edge cases
```

### What NOT to Include
- Lengthy code snippets (put in separate files)
- Full regression outputs (save to files)
- Detailed explanations (link to docs instead)
- Anything over ~100 lines total

### Updating Discipline
- **After each significant decision**: Add to decisions log
- **End of each session**: Update status, note next steps
- **Keep it trim**: If over 150 lines, consolidate or move content elsewhere

---

## Strategy 2: Session Boundaries

### Starting a Session
```bash
cd /path/to/project
claude
```

First prompt:
```
Read CLAUDE.md and [relevant files]. Today I'm working on [specific task].
Summarize what you understand about the project and this task before we begin.
```

This ensures Claude has the right context loaded before you start working.

### During a Session

**Use `/clear` for context resets:**
- Between unrelated tasks
- When switching from data cleaning to analysis
- When starting something new

**Use `/compact` when context is heavy:**
- Summarizes conversation to free space
- Preserves key context
- Use when you notice quality degradation

### Ending a Session
```
We're wrapping up. Please:
1. Summarize what we accomplished today
2. List any decisions we made that should be recorded
3. Update CLAUDE.md with current status
4. Note what we should work on next session
```

This creates a "handoff" that helps the next session start smoothly.

---

## Strategy 3: Documentation as You Go

### The "Save to File" Habit

Instead of keeping important information only in the conversation:

```
Run the main regression and save the output to output/main_results.txt
```

```
Create a summary of the data quality issues we found and save it to
docs/data_quality_notes.md
```

This way, information persists outside the context window and can be referenced later.

### Analysis Logs

For complex projects, maintain a `PROJECT_LOG.md`:

```markdown
## 2025-01-19: Robustness Checks Session

### What We Did
- Implemented robustness check #2 (region FE instead of industry FE)
- Results robust: coefficient changes from 0.12 to 0.11
- Started heterogeneity analysis by firm size

### Decisions Made
- Will report both FE structures in appendix
- Firm size categories: small (<50), medium (50-500), large (>500)

### Issues Encountered
- Memory error on full interaction model → need to subset
- Missing firm_size for 23 observations

### For Next Session
- Finish firm size heterogeneity
- Start gender heterogeneity analysis
- Review lit for expected heterogeneity patterns
```

### Why Logs Help
1. You can always point Claude to them: "Read PROJECT_LOG.md for recent context"
2. They help YOU remember what you did
3. They're useful for writing methods sections later
4. They provide audit trail for reproducibility

---

## Strategy 4: Efficient Prompting

### Be Specific About Context
Instead of:
```
Run the analysis
```

Use:
```
Using the cleaned data in data/cleaned/survey_clean.csv, run the main
specification from analysis_plan.md (log wage on union with industry×year FE).
```

### Reference Files Explicitly
```
Read code/03_main_analysis.R and add the robustness check we discussed
(dropping industry 7). Add it after the main specification around line 45.
```

### Batch Related Tasks
Instead of many small prompts:
```
I need to:
1. Add robust SE to all models in 03_main_analysis.R
2. Create a summary table of all three specifications
3. Save the table to output/tables/

Do all of these, showing me the changes before saving.
```

---

## Strategy 5: Multi-Session Workflows

### The Handoff Protocol

**End of Session A:**
```
Create a handoff note for the next session. Include:
- What we accomplished
- Current state of the analysis
- Specific next steps
- Any gotchas or things to remember

Save this to docs/handoff_2025-01-19.md and update CLAUDE.md.
```

**Start of Session B:**
```
Read CLAUDE.md and docs/handoff_2025-01-19.md.
We're continuing the analysis. Summarize where we left off.
```

### When to Start Fresh Sessions
- New phase of the project (cleaning → analysis)
- After a major milestone
- When context feels degraded
- When switching between very different tasks

### What Persists Across Sessions
- CLAUDE.md (always read)
- Files you've created
- Git history

### What Does NOT Persist
- Conversation history
- In-memory variables
- Intermediate outputs not saved to files

---

## Strategy 6: Project Structure for AI Assistance

### Recommended Layout
```
project/
├── CLAUDE.md                    # Always at root
├── analysis_plan.md             # Reference doc
├── PROJECT_LOG.md               # Session notes
├── data/
│   ├── raw/                     # Never touched after initial save
│   ├── cleaned/                 # Analysis-ready
│   └── codebooks/
├── code/
│   ├── 01_cleaning.R            # Numbered for order
│   ├── 02_exploration.R
│   └── 03_analysis.R
├── output/
│   ├── tables/
│   ├── figures/
│   └── reports/
└── docs/
    ├── handoff_*.md             # Session handoffs
    └── decisions/               # Major decision docs
```

### Why This Helps
- Clear file locations → easier for Claude to navigate
- Numbered scripts → clear execution order
- Separate raw/cleaned → safety from overwriting
- Docs folder → context that persists

---

## Quick Reference Card

| Situation | Action |
|-----------|--------|
| Starting a session | "Read CLAUDE.md and summarize" |
| Context feels stale | Try `/compact` |
| Switching tasks | Use `/clear` first |
| Important decision made | Add to CLAUDE.md decisions log |
| End of session | Do the handoff protocol |
| Need old context | "Read [file] for context" |
| Complex output | "Save this to [file]" |
| Multiple related tasks | Batch in single prompt |

---

## Common Mistakes to Avoid

1. **Not using CLAUDE.md at all**
   - You lose continuity between sessions
   - Claude has no project context

2. **Making CLAUDE.md too long**
   - Wastes context tokens
   - Key info gets buried
   - Keep under 150 lines

3. **Never using /clear**
   - Irrelevant context accumulates
   - Quality degrades over long sessions

4. **Keeping important info only in conversation**
   - Lost when session ends
   - Can't reference later

5. **Starting sessions without context**
   - Claude doesn't know your project
   - Wastes time re-explaining

6. **Not updating CLAUDE.md**
   - Gets stale and inaccurate
   - Causes confusion in future sessions

---

## The Golden Rule

**If it's important, put it in a file.**

Conversations are ephemeral. Files persist. When in doubt, ask Claude to save important information to a markdown file in your project. Your future self (and future Claude sessions) will thank you.

---

*Last updated: January 2026*
