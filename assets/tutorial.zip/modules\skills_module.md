# Using and Creating Skills
*Reference Guide (~5 min read)*

---

Skills are reusable prompt templates that standardize common workflows. Instead of typing the same complex instructions repeatedly, you invoke a skill with a simple command.

## What Are Skills?

A skill is a markdown file that contains instructions Claude follows when you invoke it. Skills can:
- Automate multi-step workflows
- Enforce consistent practices across a team
- Encode domain-specific knowledge

Skills live in `.claude/skills/` within your project.

## Built-in Skills

Claude Code comes with several built-in skills:

| Skill | What It Does |
|-------|--------------|
| `/commit` | Creates a well-formatted git commit |
| `/plan` | Creates an implementation plan before executing |
| `/init` | Initializes a CLAUDE.md file for your project |

**Try it**: Type `/commit` after making changes. Claude will review your changes and create a descriptive commit message.

## Finding Available Skills

To see what skills are available in your project:

```
What skills are available?
```

Or look in your project's `.claude/skills/` folder.

## Creating Custom Skills

### Basic Structure

Create a file at `.claude/skills/your-skill-name/SKILL.md`:

```markdown
---
description: One-line description of what this skill does
---

# Skill Name

Instructions for Claude to follow when this skill is invoked.

Be specific about:
- What inputs to expect
- What steps to take
- What outputs to produce
```

### Example: Data Audit Skill

Create `.claude/skills/data-audit/SKILL.md`:

```markdown
---
description: Detect data quality issues and anomalies in datasets
---

# Data Audit Skill

Systematic detection of data quality issues in new datasets.

## Workflow

1. **Gather Inputs**
   - Dataset file (CSV, Excel, Stata, R, Parquet)
   - Codebook or data dictionary (optional)

2. **Run Checks**
   - Structure: dimensions, variable types, empty columns
   - Missing data: rates, patterns, sentinel values (999, -1, etc.)
   - Duplicates: exact and near-duplicates on key fields
   - Ranges: values outside plausible bounds
   - Distributions: heaping, suspicious spikes, outliers
   - Consistency: impossible combinations (birth > death year)

3. **Deliver Report**
   - Critical issues (likely errors)
   - Anomalies to investigate
   - Variable-level summary table

Save report to output/data_audit_report.md
```

Then invoke with: `/data-audit` when you load a new dataset.

### Example: Regression Table Skill

Create `.claude/skills/reg-table/SKILL.md`:

```markdown
---
description: Create a publication-ready regression table
---

# Regression Table

When the user asks for a regression table:

1. Ask what variables to include if not specified
2. Run regressions with appropriate standard error clustering
3. Format using modelsummary (R) or esttab (Stata)
4. Export to both LaTeX and Word formats
5. Save to output/tables/

Always include:
- Descriptive column headers
- Standard errors in parentheses
- Significance stars with note
- Number of observations
- R-squared or pseudo-R-squared
```

### Arguments and Placeholders

Skills can accept arguments. In your SKILL.md:

```markdown
When invoked with `/my-skill [argument]`:
- If argument is "quick", produce abbreviated output
- If argument is "detailed", include full diagnostics
```

Invoke with: `/my-skill quick` or `/my-skill detailed`

## Sharing Skills with Collaborators

Skills are just files in your project. To share:

1. **Commit to git**: Skills in `.claude/skills/` travel with your repository
2. **Copy between projects**: Drag and drop the skill folder
3. **Team templates**: Create a shared repository of common skills

Example team workflow:
```bash
# Clone shared skills
git clone team-skills-repo .claude/skills/shared

# Now everyone has access to:
# /shared/data-cleaning
# /shared/regression-diagnostics
# /shared/figure-export
```

## Common Pitfalls

1. **Overly complex skills** - Keep skills focused on one task. A skill that does "everything" is hard to maintain.

2. **Missing context** - Skills don't know your project structure. Include paths or ask Claude to check CLAUDE.md.

3. **Forgetting to test** - Try your skill on a simple case before using it on real work.

4. **No error handling** - Tell Claude what to do when things go wrong (missing files, unexpected data).

## Quick Reference

| Task | How |
|------|-----|
| List available skills | "What skills are available?" |
| Create a skill | Make `.claude/skills/name/SKILL.md` |
| Invoke a skill | `/skill-name` or `/skill-name argument` |
| Share skills | Commit `.claude/skills/` to git |
| Built-in: commit | `/commit` |
| Built-in: plan | `/plan` |
| Built-in: initialize | `/init` |

---

*Part of the Claude Code Tutorial for Quantitative Social Scientists*
