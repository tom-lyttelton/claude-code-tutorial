* =============================================================================
* Solution Script: Data Exploration
* Claude Code Tutorial - Module 2
* =============================================================================

clear all
set more off

* =============================================================================
* Load Cleaned Data
* =============================================================================

import delimited "sample_data/survey_clean.csv", clear
display "Loaded " _N " observations"

* =============================================================================
* Summary Statistics
* =============================================================================

display ""
display "=== Summary Statistics: Continuous Variables ==="
summarize age education_years experience hourly_wage log_wage, detail

* Save summary stats to CSV
preserve
collapse (count) N=age (mean) Mean=age (sd) SD=age (min) Min=age (max) Max=age
export delimited "output/tables/summary_stats_age.csv", replace
restore

* Categorical variables
display ""
display "=== Summary Statistics: Categorical Variables ==="

display ""
display "Female:"
tab female, missing
summarize female

display ""
display "Union Member:"
tab union_member, missing
summarize union_member

display ""
display "Industry:"
tab industry, missing

display ""
display "Region:"
tab region, missing

display ""
display "Firm Size:"
tab firm_size, missing

display ""
display "Year:"
tab year, missing

* =============================================================================
* Visualizations
* =============================================================================

* Ensure output directories exist
capture mkdir "output"
capture mkdir "output/figures"
capture mkdir "output/tables"

* 1. Wage Distribution (excluding outliers)
histogram hourly_wage if wage_outlier == 0, ///
    bin(30) color(navy%70) ///
    title("Distribution of Hourly Wages") ///
    subtitle("Outliers excluded (wage < 0 or > $200)") ///
    xtitle("Hourly Wage ($)") ytitle("Density") ///
    scheme(s1color)
graph export "output/figures/wage_distribution.png", replace width(1600)

* 2. Log Wage Distribution
histogram log_wage if wage_outlier == 0 & !missing(log_wage), ///
    bin(30) color(forest_green%70) ///
    title("Distribution of Log Hourly Wages") ///
    subtitle("Outliers excluded") ///
    xtitle("Log(Hourly Wage)") ytitle("Density") ///
    scheme(s1color)
graph export "output/figures/log_wage_distribution.png", replace width(1600)

* 3. Wage by Union Status - Boxplot
graph box hourly_wage if wage_outlier == 0 & !missing(union_member), ///
    over(union_member, relabel(1 "Non-Union" 2 "Union")) ///
    title("Hourly Wage by Union Status") ///
    ytitle("Hourly Wage ($)") ///
    scheme(s1color)
graph export "output/figures/wage_by_union.png", replace width(1600)

* 4. Wage by Union - Density
twoway (kdensity hourly_wage if union_member == 0 & wage_outlier == 0, ///
            color(gray%70) lwidth(medthick)) ///
       (kdensity hourly_wage if union_member == 1 & wage_outlier == 0, ///
            color(navy%70) lwidth(medthick)), ///
    title("Wage Distribution by Union Status") ///
    xtitle("Hourly Wage ($)") ytitle("Density") ///
    legend(order(1 "Non-Union" 2 "Union")) ///
    scheme(s1color)
graph export "output/figures/wage_density_by_union.png", replace width(1600)

display ""
display "Figures saved to output/figures/"

* =============================================================================
* Correlation Matrix
* =============================================================================

display ""
display "=== Correlation Matrix ==="
correlate age education_years experience hourly_wage female union_member ///
    if wage_outlier == 0

* =============================================================================
* Key Bivariate Relationships
* =============================================================================

display ""
display "=== Wage by Union Status ==="
tabstat hourly_wage if wage_outlier == 0 & !missing(union_member), ///
    by(union_member) statistics(n mean sd median) columns(statistics)

* Save wage by union to CSV
preserve
keep if wage_outlier == 0 & !missing(union_member)
collapse (count) N=hourly_wage (mean) Mean_Wage=hourly_wage ///
    (sd) SD_Wage=hourly_wage (median) Median_Wage=hourly_wage, ///
    by(union_member)
export delimited "output/tables/wage_by_union.csv", replace
restore

display ""
display "=== Wage by Union Status and Industry ==="
table industry union_member if wage_outlier == 0 & !missing(union_member), ///
    statistic(mean hourly_wage) statistic(freq) nformat(%9.2f)

* Save wage by union and industry
preserve
keep if wage_outlier == 0 & !missing(union_member) & !missing(industry)
collapse (count) N=hourly_wage (mean) Mean_Wage=hourly_wage, ///
    by(industry union_member)
export delimited "output/tables/wage_by_union_industry.csv", replace
restore

display ""
display "=== Wage by Union Status and Region ==="
table region union_member if wage_outlier == 0 & !missing(union_member), ///
    statistic(mean hourly_wage) statistic(freq) nformat(%9.2f)

* Save wage by union and region
preserve
keep if wage_outlier == 0 & !missing(union_member) & !missing(region)
collapse (count) N=hourly_wage (mean) Mean_Wage=hourly_wage, ///
    by(region union_member)
export delimited "output/tables/wage_by_union_region.csv", replace
restore

display ""
display "=== Exploration report: see output/ for tables and figures ==="
