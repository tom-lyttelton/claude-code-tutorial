# Managing Context & Long Projects
*Reference Guide (~8 min read)*

---

Real research projects span weeks or months. Claude Code has a large but finite context window (200K-1M tokens depending on the model), and no built-in memory of previous sessions. Here's how to manage both problems.

## How Context Works

Everything in a session consumes context: files you read, outputs displayed, conversation history, and images. When context fills up, Claude Code **auto-compresses** older parts of the conversation to make room. This is usually seamless, but instructions given only in conversation can get lost.

**Warning signs context is getting long**:
- Claude "forgets" earlier decisions or asks questions you already answered
- Responses become more generic
- You see auto-compaction notifications

**What survives auto-compression**: CLAUDE.md files (re-injected fresh from disk), auto memory, and your most recent exchanges. What may not survive: earlier conversation details, large file contents you read earlier.

## The Memory System

Claude Code has a layered memory system. Run `/memory` at any time to see what's loaded and manage it.

### Layer 1: CLAUDE.md (Your Instructions)

CLAUDE.md is a markdown file that Claude reads at the start of **every** session. Think of it as a briefing document for a capable but amnesiac research assistant.

**Where CLAUDE.md files live**:

| Scope | Location | Use for |
|-------|----------|---------|
| **Project** | `CLAUDE.md` or `.claude/CLAUDE.md` in your repo | Project-specific standards, data locations, decisions |
| **User** | `~/.claude/CLAUDE.md` | Personal preferences across all projects |
| **Rules** | `.claude/rules/*.md` | Topic-specific instructions (loaded on demand) |

To generate a starting CLAUDE.md from your codebase, run `/init`.

**A good research project CLAUDE.md**:
```markdown
# Project: Union Wage Premium Study

## Quick Reference
- Main outcome: log(wage)
- Main treatment: union_member
- Identification: Industry x Year FE

## Current Status
- [x] Data cleaning complete
- [x] Exploration report done
- [ ] Main results
- [ ] Robustness checks

## Key Decisions
- Dropped obs before 2021 (data quality issues)
- Using log(wage), not levels
- Clustering SEs at industry level

## File Locations
- Clean data: data/cleaned/survey_clean.csv
- Main script: code/01_main_analysis.R
```

**Tips**:
- Keep it under 200 lines. Long CLAUDE.md files waste context and reduce adherence.
- Be specific: "Cluster SEs at the state level" beats "Use appropriate standard errors."
- Update it as your project evolves. Stale instructions cause confusion.

### Layer 2: Auto Memory (Claude's Notes)

Claude Code automatically saves things it learns while working with you: debugging patterns, build commands, your preferences. These persist across sessions without you doing anything.

**Where it lives**: `~/.claude/projects/<your-project>/memory/`

**How it works**:
- Claude decides what's worth saving based on corrections, discoveries, and patterns
- An index file (`MEMORY.md`) is loaded at session start (first 200 lines)
- Additional topic files are read on demand
- Everything is plain markdown. You can read, edit, or delete any of it.

**You can also ask Claude to remember things explicitly**:
```
Remember that we're clustering at the state level, not industry level.
```

Run `/memory` to see what's been saved and manage it.

### Layer 3: Session Continuity

You can pick up where you left off across sessions:

| Command | What it does |
|---------|-------------|
| `claude --continue` | Resume your most recent session |
| `claude --resume` | Choose from recent sessions |

This restores your full conversation history, so Claude remembers everything from that session.

## Context Management Commands

| Command | When to use |
|---------|-------------|
| `/memory` | See all loaded memory files, toggle auto memory, audit what Claude saved |
| `/compact` | Manually compress context (optionally with a focus: `/compact focus on the regression analysis`) |
| `/clear` | Hard reset. Wipes all context. Use sparingly. |

**Prefer `/compact` over `/clear`**. Compaction preserves key context while freeing space. `/clear` destroys everything. Only use `/clear` when context is genuinely polluted (e.g., you accidentally loaded a huge irrelevant file).

## Workflow for Multi-Session Projects

### Ending a session

```
Summarize what we accomplished today.
Update CLAUDE.md with current status and any decisions we made.
```

Or just ask: "Update CLAUDE.md." Claude will preserve what matters.

### Starting a new session

If you're not resuming (`--continue`), Claude automatically reads CLAUDE.md and auto memory. You can jump straight to work:

```
Today I'm running robustness checks on the main specification.
```

Claude will already know your project context from CLAUDE.md and auto memory.

### Organizing a larger project with rules

If your CLAUDE.md is getting long, split instructions into `.claude/rules/` files:

```
your-project/
├── CLAUDE.md                    # Core project info
└── .claude/rules/
    ├── data-conventions.md      # Variable naming, data locations
    ├── analysis-decisions.md    # Methodological choices
    └── output-standards.md      # Table/figure formatting
```

Rules without a `paths:` header load at session start. Rules with path conditions load only when Claude works with matching files.

## Quick Tips

1. **Run `/memory` periodically** to see what Claude has learned and correct anything wrong
2. **Put persistent instructions in CLAUDE.md**, not conversation. Conversation may get compressed; CLAUDE.md always reloads fresh.
3. **Save important outputs to files** (CSV, PDF, markdown). Terminal output disappears when the session ends.
4. **Use `--continue` to resume work** rather than re-explaining your project
5. **Keep CLAUDE.md concise** (under 200 lines). Link to longer docs with `@path/to/file` rather than inlining everything.

---

*Part of the Claude Code Tutorial for Quantitative Social Scientists*
