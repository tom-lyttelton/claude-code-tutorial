* =============================================================================
* Solution Script: Data Cleaning
* Claude Code Tutorial - Module 1
* =============================================================================

clear all
set more off

* =============================================================================
* Load Raw Data
* =============================================================================

import delimited "sample_data/admin_data_messy.csv", stringcols(_all) clear
local starting_n = _N

display "Starting N: `starting_n'"

* =============================================================================
* Step 1: Diagnose Data Quality Issues
* =============================================================================

* Check for duplicates
duplicates tag id, generate(dup_flag)
display "Duplicate ID records: "
count if dup_flag > 0

* Check unique values for categorical variables
tab gender, missing
tab industry_code, missing

* Check for impossible age values
destring age, generate(age_num) force
summarize age_num
count if age_num < 0 | age_num > 100

* =============================================================================
* Step 2: Standardize Missing Values
* =============================================================================

* Replace all missing value codes with Stata missing
foreach var of varlist _all {
    replace `var' = "" if inlist(`var', "-99", "NA", "missing", "Missing", ".", "N/A", "nan")
}

* Count missings
misstable summarize

* =============================================================================
* Step 3: Convert Variable Types
* =============================================================================

destring id, replace force
destring age, replace force
destring experience, replace force
destring hourly_wage, replace force
destring union_member, replace force

* Education: handle word-coded values
gen education_num = .
replace education_num = 10 if education_years == "ten"
replace education_num = 12 if education_years == "twelve"
replace education_num = 14 if education_years == "fourteen"
replace education_num = 16 if education_years == "sixteen"
replace education_num = 18 if education_years == "eighteen"
replace education_num = 20 if education_years == "twenty"
destring education_years, generate(education_destr) force
replace education_num = education_destr if education_num == .
drop education_years education_destr
rename education_num education_years

* =============================================================================
* Step 4: Standardize Gender
* =============================================================================

gen female = .
replace female = 1 if inlist(gender, "F", "f", "Female", "FEMALE", "female", "Woman", "0")
replace female = 0 if inlist(gender, "M", "m", "Male", "MALE", "male", "Man", "1")

tab gender female, missing

* =============================================================================
* Step 5: Standardize Industry
* =============================================================================

gen industry = ""
replace industry = "Manufacturing" if inlist(industry_code, "Manufacturing", "manufacturing", "MANUFACTURING", "MANUF", "Manuf.", "1")
replace industry = "Retail"        if inlist(industry_code, "Retail", "retail", "RETAIL", "Retail Trade", "2")
replace industry = "Finance"       if inlist(industry_code, "Finance", "finance", "FINANCE", "Financial", "Fin.", "3")
replace industry = "Healthcare"    if inlist(industry_code, "Healthcare", "healthcare", "HEALTHCARE", "Health Care", "Medical", "4")
replace industry = "Education"     if inlist(industry_code, "Education", "education", "EDUCATION", "Edu", "5")
replace industry = "Technology"    if inlist(industry_code, "Technology", "technology", "TECHNOLOGY", "Tech", "IT", "6")
replace industry = "Utilities"     if inlist(industry_code, "Utilities", "utilities", "UTILITIES", "Util", "7")
replace industry = "Construction"  if inlist(industry_code, "Construction", "construction", "CONSTRUCTION", "Constr.", "8")
replace industry = "Transportation" if inlist(industry_code, "Transportation", "transportation", "TRANSPORTATION", "Transport", "9")
replace industry = "Services"      if inlist(industry_code, "Services", "services", "SERVICES", "Service", "Other Services", "10")

* Encode for regression use
encode industry, generate(industry_num)
tab industry, missing

* =============================================================================
* Step 6: Standardize Region
* =============================================================================

gen region_clean = .
replace region_clean = 1 if inlist(region, "1", "Northeast", "NE")
replace region_clean = 2 if inlist(region, "2", "Midwest", "MW")
replace region_clean = 3 if inlist(region, "3", "South", "S")
replace region_clean = 4 if inlist(region, "4", "West", "W")

* =============================================================================
* Step 7: Standardize Firm Size
* =============================================================================

gen firm_size_clean = ""
replace firm_size_clean = "small"  if inlist(firm_size, "small", "Small", "SMALL", "<50", "1", "S")
replace firm_size_clean = "medium" if inlist(firm_size, "medium", "Medium", "MEDIUM", "50-500", "2", "M")
replace firm_size_clean = "large"  if inlist(firm_size, "large", "Large", "LARGE", ">500", "3", "L")

* =============================================================================
* Step 8: Parse Dates
* =============================================================================

* Try multiple date formats
gen survey_date_clean = date(survey_date, "YMD")
replace survey_date_clean = date(survey_date, "MDY") if survey_date_clean == .
replace survey_date_clean = date(survey_date, "DMY") if survey_date_clean == .
format survey_date_clean %td

gen year = year(survey_date_clean)

* =============================================================================
* Step 9: Remove Duplicates
* =============================================================================

local n_before_dedup = _N
sort id survey_date_clean
duplicates drop id, force
display "Records removed as duplicates: " `n_before_dedup' - _N

* =============================================================================
* Step 10: Handle Outliers
* =============================================================================

* Age: Remove impossible values
local n_before_age = _N
drop if age < 18 | age > 70
display "Records removed for impossible age: " `n_before_age' - _N

* Wage: Flag outliers but don't remove yet
gen wage_outlier = (hourly_wage < 0 | hourly_wage > 200) & !missing(hourly_wage)
gen log_wage = ln(hourly_wage) if hourly_wage > 0

display "Wage outliers flagged: "
count if wage_outlier == 1

* =============================================================================
* Step 11: Select Final Variables
* =============================================================================

rename region_clean region_std
rename firm_size_clean firm_size_std

keep id age female education_years experience hourly_wage log_wage ///
     wage_outlier industry industry_num region_std year union_member firm_size_std

rename region_std region
rename firm_size_std firm_size

* =============================================================================
* Step 12: Save Cleaned Data
* =============================================================================

export delimited "sample_data/survey_clean.csv", replace

display ""
display "=== CLEANING SUMMARY ==="
display "Starting N: `starting_n'"
display "Final N: " _N
display "Wage outliers flagged (not removed): "
count if wage_outlier == 1
display ""
display "Cleaned data saved to: sample_data/survey_clean.csv"
