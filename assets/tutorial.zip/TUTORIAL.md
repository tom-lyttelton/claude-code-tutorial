# Claude Code for Quantitative Social Scientists
## A 20-Minute Introduction

---

## Welcome

This tutorial shows you what Claude Code can do for your research. In about 20 minutes, you'll work through a complete data workflow - from messy data to analysis ideas.

**Time required**: ~20-25 minutes

**Prerequisites**:
- Claude Code installed (see README.md)
- Familiarity with R, Stata, or Python
- Basic comfort with the command line

---

### Interactive Mode

This tutorial has an interactive mode that guides you step-by-step:

```
/tutorial start
```

**Commands**:
- `/tutorial` - See where you are
- `/tutorial next` - Move to the next step
- `/tutorial prev` - Go back one step
- `/tutorial reset` - Start over

You can also read through this document at your own pace.

---

## Module 0: Quick Start
*~3 minutes*

### Getting In

Open your terminal and navigate to the tutorial folder:

```bash
cd path/to/tutorial
claude
```

That's it. You're in. Type naturally — Claude understands plain English. Say `y` to allow file operations (or `a` for always allow).

### Set Up Your Project

Two things to do before we start:

1. **Create a CLAUDE.md** — Claude doesn't remember between sessions. CLAUDE.md is a file Claude reads automatically at session start, acting as your project's external memory. Create one now with `/init`.

2. **Choose your statistical software** — This tutorial works with R, Python, or Stata. Tell Claude which language you want to use, and it will verify the software is accessible and update your CLAUDE.md with your preference.

**Windows users**: If Claude can't find your software, you may need to configure the path in CLAUDE.md:
- **R**: Open R and run `R.home("bin")` to find the path
- **Python**: Run `where python` in your terminal
- **Stata**: Find where Stata is installed (e.g., `C:/Program Files/Stata17/`)

**Let's see what Claude can do.**

---

## Module 1: Working with Data
*~15 minutes*

You have a messy dataset about workers and wages - panel data from 10 Midwest/Rust Belt states covering 2010-2019. Your research question: **What is the effect of union membership on wages?**

We'll work through this step by step.

### Step 1: Diagnose Data Problems

Before cleaning anything, you need to understand what's wrong with the data.

**Your task**: Ask Claude to load `sample_data/admin_data_messy.csv` and identify all the data quality issues it can find. Tell Claude you want diagnosis only - don't fix anything yet.

Think about what kinds of problems might exist: duplicates, missing values, impossible values, inconsistent coding, outliers.

Watch what Claude finds. Compare it to the codebook in `sample_data/codebook.txt` - did Claude catch everything?

---

### Step 2: Clean the Data

Now that you know what's wrong, have Claude fix it.

**Your task**: Ask Claude to clean the data based on what it found. Have it:
- Handle the missing values (which are coded in various ways)
- Standardize the categorical variables
- Deal with duplicates and outliers
- Save the cleaned data to the output folder

Let Claude handle the whole pipeline at once. Watch it work through each issue.

When it's done, take a look at what was saved. Do the sample sizes make sense given what was removed?

**Important - Update CLAUDE.md**: After saving the clean data, ask Claude to update your CLAUDE.md with:
1. What cleaning decisions were made (and why)
2. Final sample size
3. Any remaining issues to remember

This documents your decisions so future sessions have context.

---

### Step 3: Explore and Report

With clean data in hand, you need to understand what you're working with.

**Try /plan first**: Before creating the report, try using `/plan`. Tell Claude you want to create an exploration report with summary statistics and visualizations. Claude will create a plan for you to review before executing. This is useful for complex multi-step tasks.

**Your task**: Ask Claude to create an exploration report. You want:
- Summary statistics for all variables
- The distribution of wages (is it skewed? should you use logs?)
- The relationship between union membership and wages
- **Both tables AND figures** - visualize the key patterns

Have Claude save this as a report you could share with a coauthor.

Look at what Claude produces. Does the union-wage relationship look like what you'd expect from the literature?

---

### Step 4: Think About Causality

You've seen an association between union membership and wages. But is it causal?

**Your task**: Ask Claude what you would need - in terms of data or research design - to make a credible causal claim about the effect of unions on wages. What identification strategies might work? What does the structure of this data (states, years, 2010-2019) enable?

This is where your expertise matters most. Claude can lay out options and trade-offs, but you decide what's appropriate for your context.

Read Claude's suggestions critically. Which approaches make sense given what you know about this topic?

---

## What's Next?

### The Memory Limit

Remember: Claude forgets everything between sessions.

Before you close Claude, update your CLAUDE.md with:
- What you learned about the data
- Key decisions you made
- What you'd work on next

This is the habit to build. Future sessions start by reading CLAUDE.md.

### Go Deeper

These optional modules are ~5 minute reference guides for when you need them:

| Module | Topic |
|--------|-------|
| `modules/memory_module.md` | Managing context and long projects |
| `modules/prompting_module.md` | Best practices for effective prompts |
| `modules/skills_module.md` | Using and creating reusable skills |
| `modules/agents_module.md` | Using agents for specialized review |
| `modules/data_acquisition_module.md` | Finding datasets and scraping web data |
| `modules/literature_module.md` | Literature review workflows |
| `modules/paper_workflow_module.md` | Publication-ready tables and figures |

### Try Your Own Data

The best way to learn is to use Claude on a real project.

1. Navigate to one of your project folders
2. Start Claude: `claude`
3. Create a CLAUDE.md: `/init`
4. Start with: "Load my data and tell me what you see"

### Quick Reference

**Starting a session**:
```bash
cd /path/to/project
claude
```
Then: "Read CLAUDE.md. Today I'm working on [task]."

**Essential commands**:
- `/help` - Show commands
- `/clear` - Reset context
- `/init` - Create CLAUDE.md
- `/compact` - Compress context when it gets full
- `/plan` - Have Claude plan before executing

**Ending a session**:
Ask Claude to update CLAUDE.md with what you did and next steps.

### Resources

**Official Documentation**:
- Claude Code docs: https://docs.anthropic.com/en/docs/claude-code
- Best practices: https://www.anthropic.com/engineering/claude-code-best-practices

**In This Tutorial**:
- `resources/cheatsheet.md` - Quick reference card
- `modules/` - Deep-dive reference guides

---

## The Takeaway

Claude Code changes the rhythm of research work. You describe what you want, Claude handles the implementation, you evaluate the results.

---

*Tutorial version 2.1 - January 2026*
