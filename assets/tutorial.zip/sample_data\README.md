# Sample Data for Claude Code Tutorial

## Overview

This folder contains simulated administrative data for the Claude Code tutorial. The data is intentionally messy to provide realistic data cleaning exercises.

## Files

- `admin_data_messy.csv` - Main dataset with data quality issues (N ≈ 812)
- `codebook.txt` - Variable descriptions and known issues

## Data Description

The dataset simulates administrative records from a worker survey conducted 2020-2024. It contains information on wages, demographics, employment characteristics, and union membership.

**Research question for tutorial**: What is the effect of union membership on wages?

## Known Data Quality Issues

The dataset contains intentional problems that mirror real-world data challenges:

| Issue | Affected Variables | Approximate Count |
|-------|-------------------|-------------------|
| Duplicate IDs | id | 12 records |
| Impossible values | age | 45 records |
| Inconsistent coding | gender, industry, region, firm_size | Throughout |
| Mixed missing codes | experience, union_member, wage, education | 67 records |
| Outliers | hourly_wage | 15 records |
| Mixed date formats | survey_date | Throughout |
| String/numeric mix | education_years, region | Some records |

## Usage in Tutorial

- **Module 1 (Cleaning)**: Use this data to practice identifying and fixing data quality issues
- **Module 2 (Exploration)**: After cleaning, explore distributions and relationships
- **Module 3-4 (Analysis)**: Estimate the union wage premium

## Important Notes

- This is **simulated data** for educational purposes only
- The "true" union wage premium in the data generating process is approximately $5/hour
- Do NOT overwrite this file - save cleaned data to a separate location

## Generating New Data

To regenerate the dataset (e.g., with different random seed):

```bash
cd ../scripts
python generate_sample_data.py
```
