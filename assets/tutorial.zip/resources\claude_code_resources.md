# Claude Code Tutorial Resources

## Official Anthropic Resources

### Documentation
- **Official Docs**: https://code.claude.com/docs/en/overview
- **Quickstart Guide**: https://code.claude.com/docs/en/quickstart
- **Common Workflows**: https://docs.anthropic.com/en/docs/claude-code/tutorials
- **Best Practices**: https://www.anthropic.com/engineering/claude-code-best-practices
- **GitHub Repository**: https://github.com/anthropics/claude-code

### Key Documents
- [How Anthropic Teams Use Claude Code (PDF)](https://www-cdn.anthropic.com/58284b19e702b49db9302d5b6f135ad8871e7658.pdf)

---

## Claude Code for Data Scientists

### Tutorials & Guides
- [Getting Started with Claude Code for Data Scientists – Dataquest](https://www.dataquest.io/blog/getting-started-with-claude-code-for-data-scientists/)
- [Claude Code for Data Science: A First Look – Sjoerd de Haan](https://www.sjoerddehaan.com/tech/claude-code-data-science-1.html)
- [Claude Code: A Guide With Practical Examples – DataCamp](https://www.datacamp.com/tutorial/claude-code)
- [AI Data Analyst: Automate SQL Reports with Claude Code – Towards AI](https://pub.towardsai.net/claude-code-as-a-data-analyst-from-zero-to-first-report-0aa55539a19f)

### Best Practices & Workflows
- [Claude Code 2.0 Best Practices for AI Coding – Skywork](https://skywork.ai/blog/claude-code-2-0-best-practices-ai-coding-workflow-2025/)
- [Claude Code Workflow Best Practices – Sidetool](https://www.sidetool.co/post/unlocking-efficiency-claude-code-workflow-best-practices-explained/)
- [7 Essential Claude Code Best Practices – eesel.ai](https://www.eesel.ai/blog/claude-code-best-practices)
- [Cooking with Claude Code: The Complete Guide – Siddharth Bharath](https://www.siddharthbharath.com/claude-code-the-complete-guide/)

### Installation & Setup
- [Claude Code for the Rest of Us: Setup Guide – Why Try AI](https://www.whytryai.com/p/claude-code-beginner-guide)
- [Getting Started with Claude Code: A No-BS Quick Guide – Fuszti](https://fuszti.com/claude-code-setup-guide-2025/)
- [ClaudeLog Installation Guide](https://claudelog.com/install-claude-code/)
- [How I Use Claude Code + Best Tips – Builder.io](https://www.builder.io/blog/claude-code)

---

## AI for Social Science Research

### Overview Articles
- [AI and the Transformation of Social Science Research – Science](https://www.science.org/doi/10.1126/science.adi1778)
- [Can Large Language Models Transform Computational Social Science? – MIT Press](https://direct.mit.edu/coli/article/50/1/237/118498/Can-Large-Language-Models-Transform-Computational)
- [LLM Research Summaries: AI Tools for Social Scientists – GitHub](https://github.com/cognitivetech/llm-research-summaries/blob/main/social-science/AI-Tools-for-Social-Scientists.md)

### Methods & Workflows
- [The Q1Q2Q3 Workflow for Statistics and Data Science – Taylor & Francis](https://www.tandfonline.com/doi/full/10.1080/26939169.2025.2475775)
- [Workflows for Quantitative Data Analysis in the Social Sciences – Springer](https://link.springer.com/article/10.1007/s10009-014-0315-4)
- [Prompting the Machine: LLM Data Extraction for Social Scientists – SAGE](https://journals.sagepub.com/doi/10.1177/08944393251344865)

### AI + Stata
- [AI in Stata Programming: Productivity Study – Stata Conference](https://www.stata.com/meeting/spain23/slides/Spain23_Mora_AI.html)
- [Unlocking Stata with AI: Stata-MCP Server – Skywork](https://skywork.ai/skypage/en/stata-ai-mcp-server/1980888915239432192)
- [How to Analyze Data in STATA with ChatGPT – Data For Development](https://datafordev.com/how-to-analyze-data-in-stata-with-the-help-of-chatgpt/)

### Reproducibility & Scientific Rigor
- [AI-Assisted Coding: 10 Simple Rules to Maintain Scientific Rigor – The Transmitter](https://www.thetransmitter.org/artificial-intelligence/ai-assisted-coding-10-simple-rules-to-maintain-scientific-rigor/)
- [AI Support for Data Scientists: Empirical Study – PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12227384/)
- [Analyst-Inspector Framework for Evaluating Reproducibility of LLMs – arXiv](https://arxiv.org/html/2502.16395v1)

---

## Social Science Data Sources

### ICPSR (Inter-university Consortium for Political and Social Research)
- **Main Site**: https://www.icpsr.umich.edu/
- **openICPSR (Open Access)**: https://www.openicpsr.org/
- [icpsrdata R Package – Reproducible Downloads](https://github.com/fsolt/icpsrdata)
- [Using ICPSR Guide – Vassar Library](https://library.vassar.edu/icpsr)

### Other Data Repositories
- **GSS (General Social Survey)**: https://gss.norc.org/
- **ANES (American National Election Studies)**: https://electionstudies.org/
- **Census/ACS**: https://data.census.gov/
- **IPUMS**: https://ipums.org/
- **Harvard Dataverse**: https://dataverse.harvard.edu/
- **UK Data Service**: https://ukdataservice.ac.uk/

---

## Key Best Practices from Anthropic

### Core Workflow: "Explore, Plan, Code, Commit"
1. Ask Claude to read relevant files first (no writing)
2. Use subagents early to verify details
3. Ask for a plan using "think" or "think hard"
4. Create documentation with the plan
5. Implement with explicit verification
6. Commit changes and update docs

### CLAUDE.md Configuration
- Auto-loaded context for every session
- Document: bash commands, code style, testing instructions, repo etiquette
- Locations: repo root, parent directories, home folder (~/.claude/CLAUDE.md)
- Use `/init` to auto-generate starter file

### For Reproducible Research
- Be specific in instructions (avoid vague requests)
- Use test-driven development
- Create checklists for complex tasks
- Use `/clear` between unrelated tasks
- Document decisions in CLAUDE.md

### Custom Slash Commands
- Store templates in `.claude/commands/` folder
- Share with team via git
- Use for repeated workflows (data cleaning, model building, etc.)

---

## Additional Learning Resources

### General Tutorials
- [ClaudeLog – Docs, Guides, Tutorials](https://claudelog.com/)
- [Claude Code CLI Reference 2025 – eesel.ai](https://www.eesel.ai/blog/claude-code-cli-reference)
- [Shipyard Claude Code CLI Cheatsheet](https://shipyard.build/blog/claude-code-cheat-sheet/)

### Academic Use
- [Recommendations for Social Work Researchers on Use of Generative AI – JSSWR](https://www.journals.uchicago.edu/doi/10.1086/726021)
- [Using AI-Based Coding Assistants in Practice – arXiv](https://arxiv.org/html/2406.07765v1)

---

## Key Warnings for Academic Researchers

From "AI-assisted coding: 10 simple rules to maintain scientific rigor":

1. **Understand every line** - AI assistants change you from code generator to code reviewer
2. **Avoid "vibe coding"** - Generating code with little oversight may work for websites but is "a recipe for disaster for scientific programming"
3. **Test rigorously** - AI-generated code may not handle edge cases properly
4. **Document AI assistance** - For transparency and reproducibility
5. **Maintain domain expertise** - AI doesn't replace statistical/methodological knowledge

---

*Last updated: January 2026*
