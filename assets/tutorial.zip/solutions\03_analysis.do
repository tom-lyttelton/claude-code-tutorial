* =============================================================================
* Solution Script: Main Analysis
* Claude Code Tutorial - Module 4
* =============================================================================

clear all
set more off

* =============================================================================
* Load Cleaned Data
* =============================================================================

import delimited "sample_data/survey_clean.csv", clear
display "Loaded " _N " observations"

* =============================================================================
* Prepare Analysis Sample
* =============================================================================

* Remove wage outliers and records with missing key variables
keep if wage_outlier == 0
drop if missing(log_wage)
drop if missing(union_member)
drop if missing(age)
drop if missing(female)
drop if missing(education_years)
drop if missing(industry)
drop if missing(year)

display "Analysis sample N: " _N

* Encode industry for FE
encode industry, generate(industry_num)

* Create age squared
gen age_sq = age^2

* =============================================================================
* Main Specification
* =============================================================================

* Equation: log(wage) = b0 + b1*union + b2*age + b3*age^2 + b4*female +
*                       b5*education + industry_FE + year_FE + e
*
* Standard errors clustered at industry level

* Check if reghdfe is installed; if not, use areg
capture which reghdfe
if _rc == 0 {
    * Use reghdfe for multi-way FE
    reghdfe log_wage union_member age age_sq female education_years, ///
        absorb(industry_num year) cluster(industry_num)
    estimates store model_main
}
else {
    * Fallback: use factor variables
    regress log_wage union_member age age_sq female education_years ///
        i.industry_num i.year, cluster(industry_num)
    estimates store model_main
}

display ""
display "=== MAIN SPECIFICATION ==="
estimates replay model_main

* =============================================================================
* Interpretation
* =============================================================================

local union_coef = _b[union_member]
local union_se = _se[union_member]
local union_pct = (exp(`union_coef') - 1) * 100

display ""
display "=== INTERPRETATION ==="
display "Union coefficient: " %9.4f `union_coef' " (SE: " %9.4f `union_se' ")"
display "Interpretation: Union members earn approximately " ///
    %4.1f `union_pct' "% more than"
display "non-union workers with similar age, gender, education, in the same"
display "industry and year."

local ci_low = `union_coef' - 1.96 * `union_se'
local ci_high = `union_coef' + 1.96 * `union_se'
display ""
display "95% CI: " %9.4f `ci_low' " to " %9.4f `ci_high'
display "In percent terms: " %4.1f (exp(`ci_low') - 1) * 100 ///
    "% to " %4.1f (exp(`ci_high') - 1) * 100 "%"

* =============================================================================
* Robustness Check 1: Region Fixed Effects Instead
* =============================================================================

capture which reghdfe
if _rc == 0 {
    reghdfe log_wage union_member age age_sq female education_years ///
        if !missing(region), absorb(region year) cluster(region)
    estimates store model_region
}
else {
    regress log_wage union_member age age_sq female education_years ///
        i.region i.year if !missing(region), cluster(region)
    estimates store model_region
}

display ""
display "=== ROBUSTNESS 1: Region FE (instead of industry) ==="
estimates replay model_region

* =============================================================================
* Robustness Check 2: No Fixed Effects (OLS with controls)
* =============================================================================

regress log_wage union_member age age_sq female education_years, robust
estimates store model_ols

display ""
display "=== ROBUSTNESS 2: OLS with controls (no FE) ==="
display "Coefficient on union_member: " %9.4f _b[union_member]

* =============================================================================
* Robustness Check 3: Industry x Year Fixed Effects
* =============================================================================

capture which reghdfe
if _rc == 0 {
    * Create industry-year group
    egen ind_year = group(industry_num year)
    reghdfe log_wage union_member age age_sq female education_years, ///
        absorb(ind_year) cluster(industry_num)
    estimates store model_ind_year
}
else {
    egen ind_year = group(industry_num year)
    regress log_wage union_member age age_sq female education_years ///
        i.ind_year, cluster(industry_num)
    estimates store model_ind_year
}

display ""
display "=== ROBUSTNESS 3: Industry x Year FE ==="
estimates replay model_ind_year

* =============================================================================
* Heterogeneity: By Firm Size
* =============================================================================

display ""
display "=== HETEROGENEITY BY FIRM SIZE ==="

foreach size in "small" "medium" "large" {
    capture which reghdfe
    if _rc == 0 {
        reghdfe log_wage union_member age age_sq female education_years ///
            if firm_size == "`size'", absorb(industry_num year) cluster(industry_num)
    }
    else {
        regress log_wage union_member age age_sq female education_years ///
            i.industry_num i.year if firm_size == "`size'", cluster(industry_num)
    }
    display "`size' firms - Union coefficient: " %9.4f _b[union_member]
}

* =============================================================================
* Create Results Table
* =============================================================================

capture mkdir "output"
capture mkdir "output/tables"

* Main results table using esttab (if installed)
capture which esttab
if _rc == 0 {
    esttab model_main model_region model_ind_year ///
        using "output/tables/main_results.tex", ///
        replace booktabs label ///
        keep(union_member age age_sq female education_years) ///
        order(union_member age age_sq female education_years) ///
        coeflabel(union_member "Union Member" age "Age" age_sq "Age$^2$" ///
                  female "Female" education_years "Education (years)") ///
        star(* 0.10 ** 0.05 *** 0.01) ///
        se notes ///
        title("Effect of Union Membership on Log Wages") ///
        mtitles("Main" "Region FE" "Ind x Year FE") ///
        scalars("N Observations" "r2 R-squared") ///
        addnotes("Standard errors clustered at industry level in parentheses.")

    esttab model_main model_region model_ind_year ///
        using "output/tables/main_results.csv", ///
        replace ///
        keep(union_member age age_sq female education_years) ///
        order(union_member age age_sq female education_years) ///
        star(* 0.10 ** 0.05 *** 0.01) ///
        se

    display ""
    display "=== TABLES SAVED ==="
    display "Main results: output/tables/main_results.csv and .tex"
}
else {
    display "Note: esttab not installed. Install with: ssc install estout"
    display "Displaying results in console instead."
    estimates table model_main model_region model_ind_year, ///
        keep(union_member age age_sq female education_years) se
}

* =============================================================================
* Summary of Findings
* =============================================================================

display ""
display "====================================================="
display "                  SUMMARY OF FINDINGS               "
display "====================================================="
display ""
display "MAIN RESULT:"
estimates restore model_main
display "Union members earn approximately " ///
    %4.1f (exp(_b[union_member]) - 1) * 100 "% more than comparable"
display "non-union workers (controlling for age, gender, education, with"
display "industry and year fixed effects)."
display ""
display "ROBUSTNESS:"
display "- Result robust to alternative FE specifications"
estimates restore model_region
display "- Region FE: " %4.1f (exp(_b[union_member]) - 1) * 100 "%"
estimates restore model_ind_year
display "- Industry x Year FE: " %4.1f (exp(_b[union_member]) - 1) * 100 "%"
display ""
display "LIMITATIONS:"
display "- Cannot make causal claims (selection into union membership)"
display "- No panel data to control for unobserved individual heterogeneity"
display "- Results describe conditional associations, not causal effects"
display "====================================================="
