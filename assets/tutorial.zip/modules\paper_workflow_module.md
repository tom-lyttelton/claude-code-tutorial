# Publication-Ready Output
*Reference Guide (~5 min read)*

---

Getting from analysis code to journal-ready tables and figures involves a pipeline: your statistical software produces results, those results get formatted, and formatted output goes into your paper. Claude can help automate this entire workflow.

## The Output Pipeline

```
Analysis Code → Raw Results → Formatted Tables/Figures → LaTeX/Word
       ↓              ↓                    ↓                   ↓
R/Python/Stata   .csv/.rds         .tex/.docx/.png         Paper
```

The goal: one command regenerates everything when you update your analysis.

## Creating Publication-Quality Tables

### R: modelsummary (Recommended)

```r
# Clean, customizable tables
library(modelsummary)

models <- list(
  "OLS" = lm(wage ~ union, data = df),
  "With Controls" = lm(wage ~ union + education + experience, data = df),
  "Fixed Effects" = feols(wage ~ union | state + year, data = df)
)

modelsummary(models,
  output = "output/tables/main_results.tex",
  stars = c('*' = 0.1, '**' = 0.05, '***' = 0.01),
  coef_rename = c("union" = "Union Member"),
  gof_omit = "AIC|BIC|Log"
)
```

Ask Claude:
```
Create a regression table with modelsummary comparing
these three specifications. Export to LaTeX and Word.
```

### R: Other Options

| Package | Strength |
|---------|----------|
| `stargazer` | Classic, widely used |
| `kableExtra` | Flexible HTML/LaTeX |
| `gt` | Modern, publication-ready |
| `huxtable` | Good Word export |

### Stata: esttab/outreg2

```stata
* Store estimates
eststo clear
eststo: reg wage union
eststo: reg wage union education experience
eststo: reghdfe wage union, absorb(state year)

* Export table
esttab using "output/tables/main_results.tex", ///
    replace booktabs label ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    se notes
```

Ask Claude:
```
Create a Stata table using esttab with these three regressions,
formatted for a top economics journal.
```

### Python: statsmodels + stargazer

```python
import pandas as pd
import statsmodels.formula.api as smf
from stargazer.stargazer import Stargazer

# Fit models
model1 = smf.ols('wage ~ union', data=df).fit()
model2 = smf.ols('wage ~ union + education + experience', data=df).fit()

# Create table
table = Stargazer([model1, model2])
table.title('Effect of Union Membership on Wages')
table.custom_columns(['OLS', 'With Controls'])

# Export to LaTeX
with open('output/tables/main_results.tex', 'w') as f:
    f.write(table.render_latex())

# Export to HTML (for Word via browser)
with open('output/tables/main_results.html', 'w') as f:
    f.write(table.render_html())
```

Ask Claude:
```
Create a regression table using statsmodels comparing
these specifications. Export to LaTeX.
```

### AER/QJE Style Formatting

Common requirements:
- Standard errors in parentheses (not t-statistics)
- Three significance levels: 10%, 5%, 1%
- Note at bottom explaining significance stars
- Descriptive column headers
- No vertical lines; minimal horizontal lines

```
Format this table to match AER style guidelines.
Add appropriate notes about clustering and significance levels.
```

## Creating Publication-Quality Figures

### R: ggplot2 Themes

```r
library(ggplot2)

# Clean theme for publications
theme_publication <- theme_minimal() +
  theme(
    text = element_text(family = "serif", size = 11),
    axis.title = element_text(size = 12),
    legend.position = "bottom",
    panel.grid.minor = element_blank()
  )

# Apply to plot
ggplot(df, aes(x = year, y = wage, color = union)) +
  geom_line() +
  theme_publication +
  labs(x = "Year", y = "Hourly Wage ($)")

ggsave("output/figures/wage_trends.pdf", width = 6, height = 4)
```

Ask Claude:
```
Create a time series plot of wages by union status.
Use a clean theme suitable for journal publication.
Save as PDF at 6x4 inches.
```

### Python: matplotlib/seaborn

```python
import matplotlib.pyplot as plt
import seaborn as sns

# Clean theme for publications
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 11,
    'axes.titlesize': 12,
    'figure.figsize': (6, 4)
})

# Create plot
fig, ax = plt.subplots()
sns.lineplot(data=df, x='year', y='wage', hue='union', ax=ax)
ax.set_xlabel('Year')
ax.set_ylabel('Hourly Wage ($)')
plt.tight_layout()
plt.savefig('output/figures/wage_trends.pdf')
plt.close()
```

Ask Claude:
```
Create a time series plot of wages by union status using matplotlib.
Use a clean theme suitable for journal publication.
Save as PDF at 6x4 inches.
```

### Sizing and Resolution

| Output | Format | Resolution |
|--------|--------|------------|
| Print journal | PDF | Vector (scalable) |
| Online supplement | PNG | 300 dpi minimum |
| Presentations | PNG | 150 dpi is fine |
| Working paper | PDF | Vector (scalable) |

```r
# High-resolution PNG for online
ggsave("figure.png", width = 6, height = 4, dpi = 300)

# PDF for print (vector, scales perfectly)
ggsave("figure.pdf", width = 6, height = 4)
```

### PDF vs PNG

- **PDF**: Vector graphics, scales to any size, smaller files for simple plots, best for journals
- **PNG**: Raster graphics, fixed resolution, better for complex plots with many points

Rule of thumb: Use PDF unless you have >10,000 data points or complex transparency.

## Automating the Pipeline

### R: Source Script Approach

Create `run_all.R`:
```r
# Master script - regenerates all output
source("code/01_clean_data.R")
source("code/02_analysis.R")
source("code/03_tables.R")
source("code/04_figures.R")
message("All outputs regenerated!")
```

### Make-style Automation

Ask Claude:
```
Create a master script that:
1. Cleans the raw data
2. Runs all regressions
3. Generates all tables (LaTeX and Word)
4. Creates all figures
5. Logs what was produced with timestamps
```

Claude will create a script that chains everything together.

### One-Command Regeneration

The goal:
```bash
Rscript run_all.R
# or
claude "Regenerate all tables and figures"
```

And everything updates consistently.

## Journal-Specific Requirements

### Common Style Guides

| Journal | Key Requirements |
|---------|-----------------|
| AER | SE in parentheses, booktabs, specific note format |
| QJE | Similar to AER, check recent issues |
| ASR | Different table conventions, check submission guide |
| APSR | Check their LaTeX template |

### Check Before Submitting

Most journals specify:
- Maximum figure dimensions
- Required file formats
- Font requirements
- Color vs. grayscale
- Accessibility requirements

```
What are the figure requirements for [journal name]?
Adjust my figures to meet their specifications.
```

### Figure and Table Numbering

Let LaTeX handle numbering:
```latex
\begin{table}[htbp]
\caption{Effect of Union Membership on Wages}
\label{tab:main_results}
\input{output/tables/main_results.tex}
\end{table}
```

Reference with `Table \ref{tab:main_results}` - numbers update automatically.

## Common Pitfalls

1. **Hardcoding numbers** - Never type results manually. Always generate from code.

2. **Forgetting to regenerate** - After changing analysis, regenerate all tables/figures before submitting.

3. **Inconsistent formatting** - Use the same theme/style across all figures in a paper.

4. **Wrong file format** - Check journal requirements. PDF is usually safest for figures.

5. **Missing source files** - Keep the code that generates each output. You'll need to revise.

## Quick Reference

| Task | R | Python | Stata |
|------|---|--------|-------|
| Regression table | `modelsummary()` | `Stargazer()` | `esttab` |
| Export to LaTeX | `output = "file.tex"` | `render_latex()` | `using "file.tex"` |
| Export to Word | `output = "file.docx"` | `render_html()` → convert | `using "file.rtf"` |
| Publication figure | `ggsave("file.pdf")` | `plt.savefig("file.pdf")` | `graph export "file.pdf"` |
| High-res PNG | `ggsave(..., dpi = 300)` | `plt.savefig(..., dpi=300)` | `graph export ..., width(2000)` |
| Run full pipeline | `source("run_all.R")` | `python run_all.py` | `do run_all.do` |

---

*Part of the Claude Code Tutorial for Quantitative Social Scientists*
