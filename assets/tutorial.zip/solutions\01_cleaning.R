# =============================================================================
# Solution Script: Data Cleaning
# Claude Code Tutorial - Module 1
# =============================================================================

# Load required packages
library(tidyverse)
library(here)

# =============================================================================
# Load Raw Data
# =============================================================================

raw_data <- read_csv(here("sample_data", "admin_data_messy.csv"))

cat("Starting N:", nrow(raw_data), "\n")

# =============================================================================
# Step 1: Diagnose Data Quality Issues
# =============================================================================

# Check for duplicates
duplicate_ids <- raw_data %>%
  group_by(id) %>%
  filter(n() > 1) %>%
  arrange(id)

cat("\nDuplicate ID records:", nrow(duplicate_ids), "\n")

# Check unique values for categorical variables
cat("\nUnique gender values:\n")
print(table(raw_data$gender, useNA = "ifany"))

cat("\nUnique industry values:\n")
print(table(raw_data$industry_code, useNA = "ifany"))

# Check for impossible age values
cat("\nAge distribution:\n")
summary(as.numeric(raw_data$age))
cat("Ages < 0 or > 100:", sum(as.numeric(raw_data$age) < 0 | as.numeric(raw_data$age) > 100, na.rm = TRUE), "\n")

# Check missing value codes
cat("\nMissing value patterns in experience:\n")
print(table(raw_data$experience, useNA = "ifany") %>% head(20))

# =============================================================================
# Step 2: Standardize Missing Values
# =============================================================================

# Define all missing value codes
missing_codes <- c("-99", "", "NA", "missing", "Missing", ".", "N/A", "nan")

df <- raw_data %>%
  mutate(across(everything(), ~ifelse(. %in% missing_codes, NA, .)))

cat("\nNA counts after standardization:\n")
colSums(is.na(df))

# =============================================================================
# Step 3: Convert Variable Types
# =============================================================================

df <- df %>%
  mutate(
    # Numeric variables
    id = as.integer(id),
    age = as.numeric(age),
    education_years = case_when(
      education_years == "ten" ~ 10,
      education_years == "twelve" ~ 12,
      education_years == "fourteen" ~ 14,
      education_years == "sixteen" ~ 16,
      education_years == "eighteen" ~ 18,
      education_years == "twenty" ~ 20,
      TRUE ~ as.numeric(education_years)
    ),
    experience = as.numeric(experience),
    hourly_wage = as.numeric(hourly_wage),
    union_member = as.numeric(union_member)
  )

# =============================================================================
# Step 4: Standardize Gender
# =============================================================================

df <- df %>%
  mutate(
    female = case_when(
      gender %in% c("F", "f", "Female", "FEMALE", "female", "Woman", "0") ~ 1,
      gender %in% c("M", "m", "Male", "MALE", "male", "Man", "1") ~ 0,
      TRUE ~ NA_real_
    )
  )

cat("\nGender recoding:\n")
print(table(Original = raw_data$gender, Female = df$female, useNA = "ifany") %>% head(20))

# =============================================================================
# Step 5: Standardize Industry
# =============================================================================

df <- df %>%
  mutate(
    industry = case_when(
      industry_code %in% c("Manufacturing", "manufacturing", "MANUFACTURING", "MANUF", "Manuf.", "1") ~ "Manufacturing",
      industry_code %in% c("Retail", "retail", "RETAIL", "Retail Trade", "2") ~ "Retail",
      industry_code %in% c("Finance", "finance", "FINANCE", "Financial", "Fin.", "3") ~ "Finance",
      industry_code %in% c("Healthcare", "healthcare", "HEALTHCARE", "Health Care", "Medical", "4") ~ "Healthcare",
      industry_code %in% c("Education", "education", "EDUCATION", "Edu", "5") ~ "Education",
      industry_code %in% c("Technology", "technology", "TECHNOLOGY", "Tech", "IT", "6") ~ "Technology",
      industry_code %in% c("Utilities", "utilities", "UTILITIES", "Util", "7") ~ "Utilities",
      industry_code %in% c("Construction", "construction", "CONSTRUCTION", "Constr.", "8") ~ "Construction",
      industry_code %in% c("Transportation", "transportation", "TRANSPORTATION", "Transport", "9") ~ "Transportation",
      industry_code %in% c("Services", "services", "SERVICES", "Service", "Other Services", "10") ~ "Services",
      TRUE ~ NA_character_
    )
  )

cat("\nIndustry standardization:\n")
print(table(df$industry, useNA = "ifany"))

# =============================================================================
# Step 6: Standardize Region
# =============================================================================

df <- df %>%
  mutate(
    region_clean = case_when(
      region %in% c("1", "Northeast", "NE") ~ 1,
      region %in% c("2", "Midwest", "MW") ~ 2,
      region %in% c("3", "South", "S") ~ 3,
      region %in% c("4", "West", "W") ~ 4,
      TRUE ~ NA_real_
    )
  )

# =============================================================================
# Step 7: Standardize Firm Size
# =============================================================================

df <- df %>%
  mutate(
    firm_size_clean = case_when(
      firm_size %in% c("small", "Small", "SMALL", "<50", "1", "S") ~ "small",
      firm_size %in% c("medium", "Medium", "MEDIUM", "50-500", "2", "M") ~ "medium",
      firm_size %in% c("large", "Large", "LARGE", ">500", "3", "L") ~ "large",
      TRUE ~ NA_character_
    )
  )

# =============================================================================
# Step 8: Parse Dates
# =============================================================================

# Try multiple date formats
parse_date_multi <- function(x) {
  formats <- c("%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%b %d, %Y", "%B %d, %Y", "%m-%d-%Y")
  result <- as.Date(NA)
  for (fmt in formats) {
    if (is.na(result)) {
      result <- as.Date(x, format = fmt)
    }
  }
  return(result)
}

df <- df %>%
  mutate(survey_date_clean = map_vec(survey_date, parse_date_multi))

# Extract year for analysis
df <- df %>%
  mutate(year = year(survey_date_clean))

# =============================================================================
# Step 9: Remove Duplicates
# =============================================================================

n_before_dedup <- nrow(df)

df <- df %>%
  arrange(id, survey_date_clean) %>%
  distinct(id, .keep_all = TRUE)

cat("\nRecords removed as duplicates:", n_before_dedup - nrow(df), "\n")

# =============================================================================
# Step 10: Handle Outliers
# =============================================================================

# Age: Remove impossible values
n_before_age <- nrow(df)
df <- df %>%
  filter(is.na(age) | (age >= 18 & age <= 70))
cat("Records removed for impossible age:", n_before_age - nrow(df), "\n")

# Wage: Flag outliers but don't remove yet
df <- df %>%
  mutate(
    wage_outlier = hourly_wage < 0 | hourly_wage > 200,
    log_wage = ifelse(hourly_wage > 0, log(hourly_wage), NA)
  )

cat("Wage outliers flagged:", sum(df$wage_outlier, na.rm = TRUE), "\n")

# =============================================================================
# Step 11: Select and Rename Final Variables
# =============================================================================

df_clean <- df %>%
  select(
    id,
    age,
    female,
    education_years,
    experience,
    hourly_wage,
    log_wage,
    wage_outlier,
    industry,
    region = region_clean,
    year,
    union_member,
    firm_size = firm_size_clean
  )

# =============================================================================
# Step 12: Save Cleaned Data
# =============================================================================

write_csv(df_clean, here("sample_data", "survey_clean.csv"))

cat("\n=== CLEANING SUMMARY ===\n")
cat("Starting N:", nrow(raw_data), "\n")
cat("Final N:", nrow(df_clean), "\n")
cat("Duplicates removed:", nrow(raw_data) - n_before_dedup + (n_before_dedup - nrow(df) - (n_before_age - nrow(df %>% filter(is.na(age) | (age >= 18 & age <= 70))))), "\n")
cat("Impossible ages removed:", n_before_age - nrow(df), "\n")
cat("Wage outliers flagged (not removed):", sum(df_clean$wage_outlier, na.rm = TRUE), "\n")
cat("\nCleaned data saved to: sample_data/survey_clean.csv\n")

# =============================================================================
# Create Cleaning Log
# =============================================================================

cleaning_log <- sprintf("
# Data Cleaning Log

## Source
- File: sample_data/admin_data_messy.csv
- Date cleaned: %s

## Sample Size
- Starting N: %d
- Final N: %d

## Actions Taken

### Missing Values
- Standardized multiple missing codes (-99, '', 'NA', 'missing', '.', etc.) to NA
- Affected columns: experience, union_member, hourly_wage, education_years

### Duplicates
- Identified %d duplicate ID records
- Kept first occurrence, removed duplicates

### Age
- Removed %d records with impossible ages (<18 or >70)

### Gender
- Standardized 8 different codings to binary female indicator (0/1)

### Industry
- Standardized inconsistent industry codes to 10 categories

### Region
- Standardized numeric and string region codes to 1-4

### Firm Size
- Standardized to: small, medium, large

### Dates
- Parsed multiple date formats to standard Date type
- Extracted year for analysis

### Wages
- Flagged %d outliers (negative or >$200/hr)
- Created log_wage for analysis
- Did NOT remove outliers (pending decision)

## Variables in Clean Data
id, age, female, education_years, experience, hourly_wage, log_wage,
wage_outlier, industry, region, year, union_member, firm_size
",
Sys.Date(),
nrow(raw_data),
nrow(df_clean),
nrow(duplicate_ids),
n_before_age - nrow(df),
sum(df_clean$wage_outlier, na.rm = TRUE)
)

writeLines(cleaning_log, here("output", "cleaning_log.md"))
cat("\nCleaning log saved to: output/cleaning_log.md\n")
