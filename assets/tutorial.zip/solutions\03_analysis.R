# =============================================================================
# Solution Script: Main Analysis
# Claude Code Tutorial - Module 4
# =============================================================================

# Load required packages
library(tidyverse)
library(here)
library(fixest)       # For fixed effects regression
library(modelsummary) # For regression tables

# =============================================================================
# Load Cleaned Data
# =============================================================================

df <- read_csv(here("sample_data", "survey_clean.csv"))

cat("Loaded", nrow(df), "observations\n")

# =============================================================================
# Prepare Analysis Sample
# =============================================================================

# Remove wage outliers and records with missing key variables
analysis_sample <- df %>%
  filter(
    !wage_outlier,
    !is.na(log_wage),
    !is.na(union_member),
    !is.na(age),
    !is.na(female),
    !is.na(education_years),
    !is.na(industry),
    !is.na(year)
  )

cat("Analysis sample N:", nrow(analysis_sample), "\n\n")

# =============================================================================
# Main Specification
# =============================================================================

# Equation: log(wage) = β₀ + β₁*union + β₂*age + β₃*age² + β₄*female +
#                       β₅*education + industry_FE + year_FE + ε
#
# Standard errors clustered at industry level

# Create age squared
analysis_sample <- analysis_sample %>%
  mutate(age_sq = age^2)

# Main specification with industry and year fixed effects
model_main <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years |
    industry + year,
  data = analysis_sample,
  cluster = ~industry
)

cat("=== MAIN SPECIFICATION ===\n")
summary(model_main)

# =============================================================================
# Interpretation
# =============================================================================

union_coef <- coef(model_main)["union_member"]
union_se <- sqrt(vcov(model_main)["union_member", "union_member"])

cat("\n=== INTERPRETATION ===\n")
cat(sprintf("Union coefficient: %.4f (SE: %.4f)\n", union_coef, union_se))
cat(sprintf("Interpretation: Union members earn approximately %.1f%% more than\n",
            (exp(union_coef) - 1) * 100))
cat("non-union workers with similar age, gender, education, in the same\n")
cat("industry and year.\n\n")

cat("95% CI:", round(union_coef - 1.96*union_se, 4), "to",
    round(union_coef + 1.96*union_se, 4), "\n")
cat(sprintf("In percent terms: %.1f%% to %.1f%%\n",
            (exp(union_coef - 1.96*union_se) - 1) * 100,
            (exp(union_coef + 1.96*union_se) - 1) * 100))

# =============================================================================
# Robustness Check 1: Region Fixed Effects Instead
# =============================================================================

model_region_fe <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years |
    region + year,
  data = analysis_sample,
  cluster = ~region
)

cat("\n=== ROBUSTNESS 1: Region FE (instead of industry) ===\n")
summary(model_region_fe)

# =============================================================================
# Robustness Check 2: No Fixed Effects (OLS with controls)
# =============================================================================

model_ols <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years +
    factor(industry) + factor(year),
  data = analysis_sample,
  vcov = "HC1"  # Robust SEs
)

cat("\n=== ROBUSTNESS 2: OLS with controls (no absorbed FE) ===\n")
cat("Coefficient on union_member:", round(coef(model_ols)["union_member"], 4), "\n")

# =============================================================================
# Robustness Check 3: Industry × Year Fixed Effects
# =============================================================================

model_ind_year <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years |
    industry^year,
  data = analysis_sample,
  cluster = ~industry
)

cat("\n=== ROBUSTNESS 3: Industry × Year FE ===\n")
summary(model_ind_year)

# =============================================================================
# Heterogeneity: By Firm Size
# =============================================================================

analysis_sample_firmsize <- analysis_sample %>%
  filter(!is.na(firm_size))

model_small <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years |
    industry + year,
  data = filter(analysis_sample_firmsize, firm_size == "small"),
  cluster = ~industry
)

model_medium <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years |
    industry + year,
  data = filter(analysis_sample_firmsize, firm_size == "medium"),
  cluster = ~industry
)

model_large <- feols(
  log_wage ~ union_member + age + age_sq + female + education_years |
    industry + year,
  data = filter(analysis_sample_firmsize, firm_size == "large"),
  cluster = ~industry
)

cat("\n=== HETEROGENEITY BY FIRM SIZE ===\n")
cat("Small firms - Union coefficient:", round(coef(model_small)["union_member"], 4), "\n")
cat("Medium firms - Union coefficient:", round(coef(model_medium)["union_member"], 4), "\n")
cat("Large firms - Union coefficient:", round(coef(model_large)["union_member"], 4), "\n")

# =============================================================================
# Create Results Table
# =============================================================================

# Main results table
models_main <- list(
  "Main" = model_main,
  "Region FE" = model_region_fe,
  "Ind × Year FE" = model_ind_year
)

# Coefficient mapping for nice labels
coef_map <- c(
  "union_member" = "Union Member",
  "age" = "Age",
  "age_sq" = "Age²",
  "female" = "Female",
  "education_years" = "Education (years)"
)

# Generate table
table_main <- modelsummary(
  models_main,
  coef_map = coef_map,
  stars = c('*' = 0.1, '**' = 0.05, '***' = 0.01),
  gof_map = c("nobs", "r.squared", "FE: industry", "FE: year", "FE: region", "FE: industry^year"),
  output = "data.frame"
)

# Save as CSV
write_csv(table_main, here("output", "tables", "main_results.csv"))

# Save as LaTeX
modelsummary(
  models_main,
  coef_map = coef_map,
  stars = c('*' = 0.1, '**' = 0.05, '***' = 0.01),
  gof_map = c("nobs", "r.squared"),
  add_rows = tibble(
    term = c("Industry FE", "Year FE", "Region FE", "Industry × Year FE"),
    Main = c("Yes", "Yes", "No", "No"),
    `Region FE` = c("No", "Yes", "Yes", "No"),
    `Ind × Year FE` = c("No", "No", "No", "Yes")
  ),
  output = here("output", "tables", "main_results.tex"),
  title = "Effect of Union Membership on Log Wages",
  notes = c("Standard errors clustered at industry level in parentheses.",
            "* p < 0.10, ** p < 0.05, *** p < 0.01")
)

# Heterogeneity table
models_het <- list(
  "Small" = model_small,
  "Medium" = model_medium,
  "Large" = model_large
)

modelsummary(
  models_het,
  coef_map = coef_map,
  stars = c('*' = 0.1, '**' = 0.05, '***' = 0.01),
  gof_map = c("nobs", "r.squared"),
  output = here("output", "tables", "heterogeneity_firmsize.csv")
)

cat("\n=== TABLES SAVED ===\n")
cat("Main results: output/tables/main_results.csv and .tex\n")
cat("Heterogeneity: output/tables/heterogeneity_firmsize.csv\n")

# =============================================================================
# Summary of Findings
# =============================================================================

cat("\n")
cat("=====================================================\n")
cat("                  SUMMARY OF FINDINGS               \n")
cat("=====================================================\n\n")

cat("MAIN RESULT:\n")
cat(sprintf("Union members earn approximately %.1f%% more than comparable\n",
            (exp(union_coef) - 1) * 100))
cat("non-union workers (controlling for age, gender, education, with\n")
cat("industry and year fixed effects).\n\n")

cat("ROBUSTNESS:\n")
cat("- Result robust to alternative FE specifications\n")
cat("- Region FE: ", round((exp(coef(model_region_fe)["union_member"]) - 1) * 100, 1), "%\n")
cat("- Industry × Year FE: ", round((exp(coef(model_ind_year)["union_member"]) - 1) * 100, 1), "%\n\n")

cat("HETEROGENEITY:\n")
cat("- Union premium varies by firm size\n")
cat("- Small firms: ", round((exp(coef(model_small)["union_member"]) - 1) * 100, 1), "%\n")
cat("- Medium firms: ", round((exp(coef(model_medium)["union_member"]) - 1) * 100, 1), "%\n")
cat("- Large firms: ", round((exp(coef(model_large)["union_member"]) - 1) * 100, 1), "%\n\n")

cat("LIMITATIONS:\n")
cat("- Cannot make causal claims (selection into union membership)\n")
cat("- No panel data to control for unobserved individual heterogeneity\n")
cat("- Results describe conditional associations, not causal effects\n")
cat("=====================================================\n")
