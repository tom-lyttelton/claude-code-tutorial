# =============================================================================
# Solution Script: Main Analysis
# Claude Code Tutorial - Module 4
# =============================================================================

import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
from pathlib import Path

# =============================================================================
# Load Cleaned Data
# =============================================================================

base_dir = Path(__file__).resolve().parent.parent
df = pd.read_csv(base_dir / "sample_data" / "survey_clean.csv")

print(f"Loaded {len(df)} observations")

# =============================================================================
# Prepare Analysis Sample
# =============================================================================

# Remove wage outliers and records with missing key variables
analysis_sample = df[
    (~df["wage_outlier"]) &
    df["log_wage"].notna() &
    df["union_member"].notna() &
    df["age"].notna() &
    df["female"].notna() &
    df["education_years"].notna() &
    df["industry"].notna() &
    df["year"].notna()
].copy()

print(f"Analysis sample N: {len(analysis_sample)}\n")

# Create additional variables
analysis_sample["age_sq"] = analysis_sample["age"] ** 2

# Create dummy variables for fixed effects
industry_dummies = pd.get_dummies(analysis_sample["industry"], prefix="ind", drop_first=True)
year_dummies = pd.get_dummies(analysis_sample["year"], prefix="yr", drop_first=True)
analysis_sample = pd.concat([analysis_sample, industry_dummies, year_dummies], axis=1)

# =============================================================================
# Main Specification
# =============================================================================

# Equation: log(wage) = b0 + b1*union + b2*age + b3*age^2 + b4*female +
#                       b5*education + industry_FE + year_FE + e
#
# Robust standard errors (HC1)

# Build formula with industry and year dummies
ind_cols = [c for c in analysis_sample.columns if c.startswith("ind_")]
yr_cols = [c for c in analysis_sample.columns if c.startswith("yr_")]
fe_terms = " + ".join(ind_cols + yr_cols)

formula_main = f"log_wage ~ union_member + age + age_sq + female + education_years + {fe_terms}"

model_main = smf.ols(formula_main, data=analysis_sample).fit(cov_type="HC1")

print("=== MAIN SPECIFICATION ===")
# Print only the key coefficients
key_vars = ["union_member", "age", "age_sq", "female", "education_years"]
print(model_main.summary2().tables[1].loc[key_vars].round(4))
print(f"\nR-squared: {model_main.rsquared:.4f}")
print(f"N: {int(model_main.nobs)}")

# =============================================================================
# Interpretation
# =============================================================================

union_coef = model_main.params["union_member"]
union_se = model_main.bse["union_member"]

print("\n=== INTERPRETATION ===")
print(f"Union coefficient: {union_coef:.4f} (SE: {union_se:.4f})")
print(f"Interpretation: Union members earn approximately {(np.exp(union_coef) - 1) * 100:.1f}% more than")
print("non-union workers with similar age, gender, education, in the same")
print("industry and year.\n")

ci_low = union_coef - 1.96 * union_se
ci_high = union_coef + 1.96 * union_se
print(f"95% CI: {ci_low:.4f} to {ci_high:.4f}")
print(f"In percent terms: {(np.exp(ci_low) - 1) * 100:.1f}% to {(np.exp(ci_high) - 1) * 100:.1f}%")

# =============================================================================
# Robustness Check 1: Region Fixed Effects Instead
# =============================================================================

# Create region dummies
region_dummies = pd.get_dummies(analysis_sample["region"], prefix="reg", drop_first=True)
analysis_sample = pd.concat([analysis_sample, region_dummies], axis=1)
reg_cols = [c for c in analysis_sample.columns if c.startswith("reg_")]
fe_region = " + ".join(reg_cols + yr_cols)

formula_region = f"log_wage ~ union_member + age + age_sq + female + education_years + {fe_region}"
model_region = smf.ols(formula_region, data=analysis_sample.dropna(subset=["region"])).fit(cov_type="HC1")

print("\n=== ROBUSTNESS 1: Region FE (instead of industry) ===")
print(f"Coefficient on union_member: {model_region.params['union_member']:.4f}")
print(f"SE: {model_region.bse['union_member']:.4f}")

# =============================================================================
# Robustness Check 2: No Fixed Effects (OLS with controls only)
# =============================================================================

formula_ols = "log_wage ~ union_member + age + age_sq + female + education_years"
model_ols = smf.ols(formula_ols, data=analysis_sample).fit(cov_type="HC1")

print("\n=== ROBUSTNESS 2: OLS with controls (no FE) ===")
print(f"Coefficient on union_member: {model_ols.params['union_member']:.4f}")

# =============================================================================
# Robustness Check 3: Industry x Year Fixed Effects
# =============================================================================

# Create interaction dummies
analysis_sample["ind_year"] = (
    analysis_sample["industry"].astype(str) + "_" + analysis_sample["year"].astype(str)
)
ind_year_dummies = pd.get_dummies(analysis_sample["ind_year"], prefix="iy", drop_first=True)
analysis_sample = pd.concat([analysis_sample, ind_year_dummies], axis=1)
iy_cols = [c for c in analysis_sample.columns if c.startswith("iy_")]
fe_iy = " + ".join(iy_cols)

formula_iy = f"log_wage ~ union_member + age + age_sq + female + education_years + {fe_iy}"
model_iy = smf.ols(formula_iy, data=analysis_sample).fit(cov_type="HC1")

print("\n=== ROBUSTNESS 3: Industry x Year FE ===")
print(f"Coefficient on union_member: {model_iy.params['union_member']:.4f}")

# =============================================================================
# Heterogeneity: By Firm Size
# =============================================================================

analysis_fs = analysis_sample[analysis_sample["firm_size"].notna()]

print("\n=== HETEROGENEITY BY FIRM SIZE ===")
for size in ["small", "medium", "large"]:
    subset = analysis_fs[analysis_fs["firm_size"] == size]
    m = smf.ols(formula_main, data=subset).fit(cov_type="HC1")
    print(f"{size.capitalize()} firms - Union coefficient: {m.params['union_member']:.4f}")

# =============================================================================
# Create Results Table (CSV)
# =============================================================================

results = pd.DataFrame({
    "Variable": key_vars,
    "Main": [f"{model_main.params[v]:.4f}" for v in key_vars],
    "Main_SE": [f"({model_main.bse[v]:.4f})" for v in key_vars],
    "Region_FE": [f"{model_region.params[v]:.4f}" for v in key_vars],
    "Region_FE_SE": [f"({model_region.bse[v]:.4f})" for v in key_vars],
    "Ind_x_Year_FE": [f"{model_iy.params[v]:.4f}" for v in key_vars],
    "Ind_x_Year_FE_SE": [f"({model_iy.bse[v]:.4f})" for v in key_vars],
})

# Add goodness-of-fit rows
gof = pd.DataFrame([
    {"Variable": "N", "Main": str(int(model_main.nobs)),
     "Region_FE": str(int(model_region.nobs)),
     "Ind_x_Year_FE": str(int(model_iy.nobs))},
    {"Variable": "R-squared", "Main": f"{model_main.rsquared:.4f}",
     "Region_FE": f"{model_region.rsquared:.4f}",
     "Ind_x_Year_FE": f"{model_iy.rsquared:.4f}"},
    {"Variable": "Industry FE", "Main": "Yes", "Region_FE": "No", "Ind_x_Year_FE": "No"},
    {"Variable": "Year FE", "Main": "Yes", "Region_FE": "Yes", "Ind_x_Year_FE": "No"},
    {"Variable": "Region FE", "Main": "No", "Region_FE": "Yes", "Ind_x_Year_FE": "No"},
    {"Variable": "Industry x Year FE", "Main": "No", "Region_FE": "No", "Ind_x_Year_FE": "Yes"},
])

results_full = pd.concat([results, gof], ignore_index=True)
results_full.to_csv(base_dir / "output" / "tables" / "main_results.csv", index=False)

print("\n=== TABLES SAVED ===")
print("Main results: output/tables/main_results.csv")

# =============================================================================
# Summary of Findings
# =============================================================================

print("\n")
print("=" * 53)
print("                  SUMMARY OF FINDINGS               ")
print("=" * 53)

print(f"\nMAIN RESULT:")
print(f"Union members earn approximately {(np.exp(union_coef) - 1) * 100:.1f}% more than comparable")
print("non-union workers (controlling for age, gender, education, with")
print("industry and year fixed effects).\n")

print("ROBUSTNESS:")
print("- Result robust to alternative FE specifications")
print(f"- Region FE: {(np.exp(model_region.params['union_member']) - 1) * 100:.1f}%")
print(f"- Industry x Year FE: {(np.exp(model_iy.params['union_member']) - 1) * 100:.1f}%\n")

print("LIMITATIONS:")
print("- Cannot make causal claims (selection into union membership)")
print("- No panel data to control for unobserved individual heterogeneity")
print("- Results describe conditional associations, not causal effects")
print("=" * 53)
