# =============================================================================
# Solution Script: Data Exploration
# Claude Code Tutorial - Module 2
# =============================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from datetime import date

# =============================================================================
# Load Cleaned Data
# =============================================================================

base_dir = Path(__file__).resolve().parent.parent
df = pd.read_csv(base_dir / "sample_data" / "survey_clean.csv")

print(f"Loaded {len(df)} observations")

# Create output directories
(base_dir / "output" / "tables").mkdir(parents=True, exist_ok=True)
(base_dir / "output" / "figures").mkdir(parents=True, exist_ok=True)

# =============================================================================
# Summary Statistics
# =============================================================================

continuous_vars = ["age", "education_years", "experience", "hourly_wage", "log_wage"]

stats_continuous = df[continuous_vars].describe().T
stats_continuous["Pct_Missing"] = df[continuous_vars].isna().mean() * 100
stats_continuous = stats_continuous[["count", "mean", "std", "min", "max", "Pct_Missing"]]
stats_continuous.columns = ["N", "Mean", "SD", "Min", "Max", "Pct_Missing"]
stats_continuous = stats_continuous.round(2)

print("\n=== Summary Statistics: Continuous Variables ===")
print(stats_continuous)

stats_continuous.to_csv(base_dir / "output" / "tables" / "summary_stats_continuous.csv")

# Categorical variables
print("\n=== Summary Statistics: Categorical Variables ===")

print(f"\nFemale:")
print(df["female"].value_counts(dropna=False))
print(f"Proportion female: {df['female'].mean():.3f}")

print(f"\nUnion Member:")
print(df["union_member"].value_counts(dropna=False))
print(f"Proportion union: {df['union_member'].mean():.3f}")

print(f"\nIndustry:")
print(df["industry"].value_counts(dropna=False))

print(f"\nRegion:")
print(df["region"].value_counts(dropna=False))

print(f"\nFirm Size:")
print(df["firm_size"].value_counts(dropna=False))

print(f"\nYear:")
print(df["year"].value_counts(dropna=False).sort_index())

# =============================================================================
# Visualizations
# =============================================================================

# Set publication-friendly defaults
plt.rcParams.update({
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.labelsize": 12,
    "figure.figsize": (8, 5),
})

# 1. Wage Distribution
df_valid = df[~df["wage_outlier"]]

fig, ax = plt.subplots()
ax.hist(df_valid["hourly_wage"].dropna(), bins=30, color="steelblue", edgecolor="white", alpha=0.7)
ax.set_title("Distribution of Hourly Wages", fontweight="bold")
ax.set_xlabel("Hourly Wage ($)")
ax.set_ylabel("Count")
ax.text(0.98, 0.95, "Outliers excluded (wage < 0 or > $200)",
        transform=ax.transAxes, ha="right", va="top", fontsize=9, color="gray")
plt.tight_layout()
plt.savefig(base_dir / "output" / "figures" / "wage_distribution.png", dpi=300)
plt.close()

# 2. Log Wage Distribution
fig, ax = plt.subplots()
ax.hist(df_valid["log_wage"].dropna(), bins=30, color="darkgreen", edgecolor="white", alpha=0.7)
ax.set_title("Distribution of Log Hourly Wages", fontweight="bold")
ax.set_xlabel("Log(Hourly Wage)")
ax.set_ylabel("Count")
plt.tight_layout()
plt.savefig(base_dir / "output" / "figures" / "log_wage_distribution.png", dpi=300)
plt.close()

# 3. Wage by Union Status - Boxplot
df_union = df_valid[df_valid["union_member"].notna()].copy()
df_union["Union"] = df_union["union_member"].map({1: "Union", 0: "Non-Union"})

fig, ax = plt.subplots(figsize=(6, 5))
colors = {"Non-Union": "gray", "Union": "steelblue"}
sns.boxplot(data=df_union, x="Union", y="hourly_wage", palette=colors, ax=ax)
ax.set_title("Hourly Wage by Union Status", fontweight="bold")
ax.set_xlabel("")
ax.set_ylabel("Hourly Wage ($)")
plt.tight_layout()
plt.savefig(base_dir / "output" / "figures" / "wage_by_union.png", dpi=300)
plt.close()

# 4. Wage by Union - Density
fig, ax = plt.subplots()
for status, color in [("Non-Union", "gray"), ("Union", "steelblue")]:
    subset = df_union[df_union["Union"] == status]["hourly_wage"].dropna()
    subset.plot.kde(ax=ax, label=status, color=color, alpha=0.7)
ax.set_title("Wage Distribution by Union Status", fontweight="bold")
ax.set_xlabel("Hourly Wage ($)")
ax.set_ylabel("Density")
ax.legend()
plt.tight_layout()
plt.savefig(base_dir / "output" / "figures" / "wage_density_by_union.png", dpi=300)
plt.close()

print("\nFigures saved to output/figures/")

# =============================================================================
# Correlation Matrix
# =============================================================================

cor_vars = df_valid[["age", "education_years", "experience",
                     "hourly_wage", "female", "union_member"]].dropna()
cor_matrix = cor_vars.corr()

print("\n=== Correlation Matrix ===")
print(cor_matrix.round(3))

cor_matrix.to_csv(base_dir / "output" / "tables" / "correlation_matrix.csv")

# =============================================================================
# Key Bivariate Relationships
# =============================================================================

print("\n=== Wage by Union Status ===")
wage_by_union = (
    df_valid[df_valid["union_member"].notna()]
    .groupby("union_member")["hourly_wage"]
    .agg(["count", "mean", "std", "median"])
    .rename(columns={"count": "N", "mean": "Mean_Wage", "std": "SD_Wage", "median": "Median_Wage"})
)
wage_by_union.index = wage_by_union.index.map({0: "Non-Union", 1: "Union"})
print(wage_by_union.round(2))

wage_by_union.to_csv(base_dir / "output" / "tables" / "wage_by_union.csv")

raw_premium = wage_by_union.loc["Union", "Mean_Wage"] - wage_by_union.loc["Non-Union", "Mean_Wage"]
print(f"\nRaw union wage premium: ${raw_premium:.2f}")

print("\n=== Wage by Union Status and Industry ===")
wage_by_union_industry = (
    df_valid[df_valid["union_member"].notna() & df_valid["industry"].notna()]
    .groupby(["industry", "union_member"])["hourly_wage"]
    .agg(["count", "mean"])
    .unstack("union_member")
    .round(2)
)
print(wage_by_union_industry)
wage_by_union_industry.to_csv(base_dir / "output" / "tables" / "wage_by_union_industry.csv")

print("\n=== Wage by Union Status and Region ===")
wage_by_union_region = (
    df_valid[df_valid["union_member"].notna() & df_valid["region"].notna()]
    .groupby(["region", "union_member"])["hourly_wage"]
    .agg(["count", "mean"])
    .unstack("union_member")
    .round(2)
)
print(wage_by_union_region)
wage_by_union_region.to_csv(base_dir / "output" / "tables" / "wage_by_union_region.csv")

# =============================================================================
# Generate Exploration Report
# =============================================================================

union_mean = df_valid[df_valid["union_member"] == 1]["hourly_wage"].mean()
nonunion_mean = df_valid[df_valid["union_member"] == 0]["hourly_wage"].mean()
union_sd = df_valid[df_valid["union_member"] == 1]["hourly_wage"].std()
nonunion_sd = df_valid[df_valid["union_member"] == 0]["hourly_wage"].std()
union_n = int((df_valid["union_member"] == 1).sum())
nonunion_n = int((df_valid["union_member"] == 0).sum())
premium = union_mean - nonunion_mean
premium_pct = (union_mean / nonunion_mean - 1) * 100

report = f"""# Data Exploration Report

## 1. Data Overview

**Source**: Administrative worker survey data (simulated)
**Time Period**: 2020-2024
**Unit of Analysis**: Individual worker
**Sample Size**: {len(df)} observations (after cleaning)

### Sample Construction
- Started with 812 raw records
- Removed duplicates and records with impossible ages
- Flagged {int(df['wage_outlier'].sum())} wage outliers (not removed from analysis sample)

## 2. Variable Descriptions

### Outcome Variable
- **hourly_wage**: Hourly wage in US dollars
  - Mean: ${df_valid['hourly_wage'].mean():.2f}, SD: ${df_valid['hourly_wage'].std():.2f}
  - Range: ${df_valid['hourly_wage'].min():.2f} - ${df_valid['hourly_wage'].max():.2f}
  - Right-skewed distribution; log transformation recommended

### Key Independent Variable
- **union_member**: Binary indicator (1 = union member)
  - Union membership rate: {df['union_member'].mean() * 100:.1f}%
  - N union members: {union_n}
  - N non-union: {nonunion_n}

### Control Variables
- **age**: Age in years (Mean: {df['age'].mean():.1f}, SD: {df['age'].std():.1f})
- **female**: Binary indicator ({df['female'].mean() * 100:.1f}% female)
- **education_years**: Years of education (Mean: {df['education_years'].mean():.1f})
- **experience**: Years of work experience (Mean: {df['experience'].mean():.1f})

## 3. Key Distributions

### Wage Distribution
- Hourly wages range from ${df_valid['hourly_wage'].min():.2f} to ${df_valid['hourly_wage'].max():.2f} (excluding outliers)
- Distribution is right-skewed
- **Recommendation**: Use log(wage) as outcome variable

See figures:
- `output/figures/wage_distribution.png`
- `output/figures/log_wage_distribution.png`

## 4. Bivariate Relationships

### Union-Wage Relationship (Key Finding)
| Status | N | Mean Wage | SD |
|--------|---|-----------|-----|
| Non-Union | {nonunion_n} | ${nonunion_mean:.2f} | ${nonunion_sd:.2f} |
| Union | {union_n} | ${union_mean:.2f} | ${union_sd:.2f} |

**Raw union premium**: ${premium:.2f} ({premium_pct:.1f}%)

See figure: `output/figures/wage_by_union.png`

## 5. Correlation Matrix

Key correlations:
- Age and experience: r = {cor_matrix.loc['age', 'experience']:.3f} (high, as expected - do not include both)
- Education and wage: r = {cor_matrix.loc['education_years', 'hourly_wage']:.3f} (positive)
- Union and wage: r = {cor_matrix.loc['union_member', 'hourly_wage']:.3f} (positive)

## 6. Implications for Analysis

### Functional Form
- Use **log(hourly_wage)** as outcome (right-skewed distribution)

### Controls to Include
- **age** (or experience, but not both - highly correlated)
- **education_years**
- **female**
- **firm_size** (may be mediator - test with and without)

### Fixed Effects
- **industry**: Strong wage differences across industries
- **year**: Control for time trends

---

*Report generated: {date.today()}*
"""

report_path = base_dir / "output" / "data_exploration_report.md"
report_path.write_text(report)
print(f"\n=== Exploration report saved to: {report_path} ===")
