# Using Agents
*Reference Guide (~5 min read)*

---

When you ask Claude to review your code for bugs, check the formatting, and verify the statistics all at once, it will skim everything and do a mediocre job at all of them. Agents solve this by splitting work into focused specialists.

## What Are Agents?

An agent is a separate Claude instance with a specific job. Instead of one Claude trying to do everything, you get multiple Claudes that each focus on one thing:

| Single Claude | Specialized Agents |
|--------------|-------------------|
| "Review my code for style, bugs, and stats" | **Code reviewer**: style and correctness only |
| Catches some issues, misses others | **Stats checker**: methodology and numbers only |
| Attention spread thin across dimensions | Each agent gives full attention to its dimension |

This is the same principle behind peer review — you wouldn't ask one reviewer to check grammar, methodology, and theory simultaneously.

## Two Ways to Use Agents

### 1. Claude Spawns Them Automatically

When Claude encounters a complex task, it can break it into subtasks and delegate each to a subagent. You don't need to do anything — Claude decides when parallelism helps.

For example, if you ask Claude to review a long analysis script, it might spawn one subagent to check the data cleaning logic and another to check the statistical models, then synthesize both reports.

### 2. You Create Custom Agents

You can define specialized agents for your project. These live in `.claude/agents/` as markdown files with instructions.

## Creating a Custom Agent

Create a file at `.claude/agents/your-agent-name.md`:

```markdown
---
name: data-reviewer
description: Reviews datasets for quality issues
model: sonnet
tools: ["Read", "Grep", "Glob", "Bash"]
---

# Data Quality Reviewer

## Role
You are a data quality specialist reviewing datasets for a quantitative
social science project.

## What to Check
1. Missing data patterns — are they random or systematic?
2. Variable distributions — anything bimodal, heaped, or truncated?
3. Impossible values — ages over 120, negative incomes, future dates
4. Sample composition — does it match what the codebook promises?
5. Panel consistency — do IDs appear the expected number of times?

## Report Format
Organize findings by severity:
- **Critical**: Errors that would invalidate analysis
- **Warning**: Anomalies that need investigation
- **Note**: Minor issues or things to document
```

### YAML Frontmatter Fields

The `---` block at the top configures the agent:

| Field | What It Does | Example |
|-------|-------------|---------|
| `name` | Agent identifier | `data-reviewer` |
| `description` | One-line summary (shown in agent list) | `Reviews datasets for quality issues` |
| `model` | Which Claude model to use | `sonnet`, `opus`, `haiku` |
| `tools` | Which tools the agent can use | `["Read", "Grep", "Glob"]` |
| `maxTurns` | Limit how many steps the agent takes | `15` |

**Restricting tools matters.** An agent with only `Read`, `Grep`, and `Glob` can review files but can't modify them — it's a read-only reviewer. This is useful when you want honest critique without the agent "fixing" its own findings.

## Practical Examples for Research

### Code Reviewer

```markdown
---
name: code-reviewer
description: Reviews R/Python/Stata scripts for correctness and reproducibility
tools: ["Read", "Grep", "Glob"]
---

# Code Reviewer

## Role
Review research code for correctness and reproducibility.

## Checklist
1. Does the script run top-to-bottom without errors?
2. Are random seeds set before any stochastic operations?
3. Are file paths relative (not hardcoded to one machine)?
4. Do variable names match between the code and any documentation?
5. Are results saved to files, or only printed to console?
6. Are package dependencies loaded at the top?

## What NOT to Review
- Code style preferences (tabs vs spaces, naming conventions)
- Performance optimization
- Anything not directly related to correctness
```

### Replication Checker

```markdown
---
name: replication-checker
description: Verifies that code output matches claims in paper drafts
tools: ["Read", "Grep", "Glob", "Bash"]
---

# Replication Checker

## Role
Cross-reference paper claims against code output.

## Process
1. Read the paper draft — extract every empirical claim
   (point estimates, standard errors, sample sizes, p-values)
2. Find the code that produces each claim
3. Flag any discrepancy: number in paper vs number in code/output

## Report
For each claim, report:
- Paper says: [exact text]
- Code produces: [value from output]
- Status: MATCH / MISMATCH / CANNOT VERIFY
```

## The Adversarial Pattern

The most powerful agent pattern separates **criticism** from **fixing**:

```
Critic agent (read-only)     Fixer agent (can edit)
        │                            │
   Finds 8 issues              Fixes 8 issues
        │                            │
   Re-reviews ──────────────> Still 2 remaining
        │                            │
   Re-reviews ──────────────> All clear
```

**Why this works**: The critic can't edit files, so it has no incentive to downplay problems. The fixer can't approve its own work — the critic re-checks. This prevents Claude from saying "looks good" about its own output.

You don't need to set this up yourself — it's a pattern to be aware of when designing agents for team workflows or complex projects.

## When to Use Agents vs. Just Asking Claude

| Situation | Approach |
|-----------|----------|
| One-off question or quick task | Just ask Claude directly |
| Recurring review you do the same way every time | Create a custom agent |
| Task that benefits from focused attention on one dimension | Custom agent |
| Multiple independent checks that could run in parallel | Multiple agents |
| You want critique that isn't biased by having written the code | Read-only agent |

**Start simple.** Most research tasks don't need custom agents. Use them when you notice yourself giving Claude the same complex instructions repeatedly, or when you want more thorough review than a single prompt provides.

## Quick Reference

| Task | How |
|------|-----|
| Create an agent | Make `.claude/agents/name.md` with YAML frontmatter |
| Make an agent read-only | Set `tools: ["Read", "Grep", "Glob"]` |
| Limit agent runtime | Set `maxTurns: 15` |
| Use a cheaper model | Set `model: sonnet` or `model: haiku` |
| List your agents | Check `.claude/agents/` folder |

---

*Part of the Claude Code Tutorial for Quantitative Social Scientists*
